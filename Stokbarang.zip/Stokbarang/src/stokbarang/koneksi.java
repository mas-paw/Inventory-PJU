/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stokbarang;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author xLee
 */
public class koneksi {  
    Connection conn;
    String user = "root";
    String pass = "";
    String url = "jdbc:MySQL://Localhost/pju_barang";
    
    public Connection config(){
        try{
            Class.forName("org.gjt.mm.mysql.Driver");
            conn = DriverManager.getConnection(url,user,pass);
//            System.out.println("Database Connect");
        }catch(Exception e){
            System.out.println("Database unconnect "+e.getMessage());
        }
        return conn;
    }
}
