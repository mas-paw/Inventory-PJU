/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stokbarang;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author xLee
 */
public class RekapKeluarMasuk extends javax.swing.JFrame {
    koneksi konek = new koneksi();
    Statement stmt;
    ResultSet rs;
    ResultSetMetaData meta;
    String pilih,tgl1,tanggal,stok_lama;
    Calendar cal;
    SimpleDateFormat newtgl = new SimpleDateFormat("yyyy/MM/dd");
    Date tgl = new Date();
    int month,year;
    /**
     * Creates new form PemakaianBarang
     */
    public RekapKeluarMasuk() {
        initComponents();
        setLocationRelativeTo(null);
        cal = Calendar.getInstance();
        cal.setTime(tgl);
        
        
    }
    public void initiateBulan(){
        pilih ="";
        tanggal = txt_bulan.getSelectedItem()+" "+txt_tahun.getYear();
        switch(txt_bulan.getSelectedItem().toString()){
            case "Januari": 
                pilih = "01";
                stok_lama="12";
                month =0;
                year = txt_tahun.getYear()-1;
                break;
            case "Februari":
                pilih = "02";
                stok_lama="1";
                month =1;
                year = txt_tahun.getYear();
                break;
            case "Maret":
                pilih = "03";
                stok_lama="2";
                month =2;
                year = txt_tahun.getYear();
                break;
            case "April":
                pilih ="04";
                stok_lama="3";
                month =3;
                year = txt_tahun.getYear();
                break;
            case "Mei":
                pilih = "05";
                stok_lama="4";
                month =4;
                year = txt_tahun.getYear();
                break;
            case "Juni": 
                pilih = "06";
                stok_lama="5";
                month =5;
                year = txt_tahun.getYear();
                break;
            case "Juli":
                pilih = "07";
                stok_lama="6";
                month = 6;
                year = txt_tahun.getYear();
                break;
            case "Agustus":
                pilih = "08";
                stok_lama="7";
                month = 7;
                year = txt_tahun.getYear();
                break;
            case "September":
                pilih = "09";
                stok_lama="8";
                month = 8;
                year = txt_tahun.getYear();
                break;
            case "Oktober":
                pilih = "10";
                stok_lama="9";
                month = 9;
                year = txt_tahun.getYear();
                break;
            case "November":
                pilih = "11";
                stok_lama="10";
                month = 10;
                year = txt_tahun.getYear();
                break;
            case "Desember":
                pilih = "12";
                stok_lama="11";
                month = 11;
                year = txt_tahun.getYear();
                break;
        }
        
        cal.set(Calendar.MONTH, month);
        tgl1 = newtgl.format(cal.getTime());
    }
    public void lihatData(){
        try {
                konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select stok_barang.no,barang_keluar.tanggal as tanggal,stok_barang.nama_barang,ifnull(temp_barang_masuk.jumlah,0) as barang_masuk,sum(barang_keluar.jumlah)as jumlah,stok_barang.jumlah as sisa from barang_keluar INNER JOIN stok_barang on stok_barang.nama_barang = barang_keluar.nama_barang LEFT OUTER JOIN temp_barang_masuk on temp_barang_masuk.no = stok_barang.no where MONTH(barang_keluar.tanggal) = '"+pilih+"' AND YEAR(barang_keluar.tanggal)= '"+txt_tahun.getYear()+"' group by barang_keluar.no";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Barang Masuk", "Jumlah Pakai","Sisa"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getInt("no");
                dataTable[x][1] = rs.getString("tanggal");
                dataTable[x][2] = rs.getString("nama_barang");
                dataTable[x][3] = rs.getString("barang_masuk");
                dataTable[x][4] = rs.getString("jumlah");
                dataTable[x][5] = rs.getString("sisa");
                x++;
            }
            tabel_pemakaian.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void saveTempMasuk(){
        try {
            konek.config();
            stmt = konek.conn.createStatement();
            String sql = "delete from temp_barang_masuk";
            stmt.executeUpdate(sql);
            String sqll = "insert into temp_barang_masuk(no,nama_barang,tanggal,jumlah)SELECT barang_masuk.no,barang_masuk.nama_barang,barang_masuk.tanggal,sum(barang_masuk.jumlah) from barang_masuk WHERE month(barang_masuk.tanggal)='"+pilih+"' AND YEAR(barang_masuk.tanggal)='"+txt_tahun.getYear()+"' GROUP BY barang_masuk.no";            
            stmt.executeUpdate(sqll);
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void record_kosong(){
     DefaultTableModel model = (DefaultTableModel) tabel_pemakaian.getModel();
        int row = tabel_pemakaian.getRowCount();
        if(row<=0){
            JOptionPane.showMessageDialog(null, "Data Tidak Ditemukan");
        }
    }
    public void simpanLaporan(){
        try{
            konek.config();
            DefaultTableModel dataModel = (DefaultTableModel) tabel_pemakaian.getModel();    
            stmt = konek.conn.createStatement();
            if (tabel_pemakaian.getRowCount() > 0) {
                int i = 0; 
                String sql = "delete from hasil_pakai";
                stmt.executeUpdate(sql);
                while (i < tabel_pemakaian.getRowCount()){
                    String sqll = "insert into hasil_pakai(no,tanggal,nama_barang,barang_masuk,jumlah_pakai,sisa) values('" + tabel_pemakaian.getValueAt(i,0)+ "','" + tabel_pemakaian.getValueAt(i,1)+ "','" + tabel_pemakaian.getValueAt(i,2)+ "','" + tabel_pemakaian.getValueAt(i,3)+ "','" + tabel_pemakaian.getValueAt(i,4)+ "','" + tabel_pemakaian.getValueAt(i,5)+ "')" ;            
                    stmt.executeUpdate(sqll);    
                    i++;    
                }
            stmt.close();
            }else
                JOptionPane.showMessageDialog(rootPane,"Pilih Bulan dan Tahun Untuk Pemakaian Barang Terlebih Dahulu");
            
        } catch (Exception e){
//            JOptionPane.showMessageDialog(null, e); 
        }
    }
    
    public void simpanStokLama(){
        try{
            konek.config();
            DefaultTableModel dataModel = (DefaultTableModel) tabel_pemakaian.getModel();    
            if (tabel_pemakaian.getRowCount() > 0) {
                stmt = konek.conn.createStatement();
                String sqll = "insert into stok_barang_lama(no,tanggal,nama_barang,stok_barang)SELECT no,'"+tgl1+"',nama_barang,jumlah from stok_barang" ;            
                stmt.executeUpdate(sqll);    
             dataModel.setRowCount(0);
             stmt.close();
            }else
                JOptionPane.showMessageDialog(rootPane,"Pilih Bulan dan Tahun Untuk Pemakaian Barang Terlebih Dahulu");
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e); 
        }
        bersihkan();
    }
    
    public void simpanPersediaanBarang(){
        try{
            konek.config();
            DefaultTableModel dataModel = (DefaultTableModel) tabel_pemakaian.getModel();    
            stmt = konek.conn.createStatement();
            String sqll = "insert into pemakaian_barang(no,nama_barang,stok_bulan_lalu,barang_masuk,tanggal,jumlah_pakai,sisa)SELECT stok_barang_lama.no,stok_barang_lama.nama_barang, stok_barang_lama.stok_barang,temp_barang_masuk.jumlah,'"+tanggal+"' as tanggal,IFNULL(jumlah_pakai,0)as jumlah_pakai,stok_barang.jumlah as sisa FROM `hasil_pakai` RIGHT JOIN stok_barang_lama on stok_barang_lama.nama_barang = hasil_pakai.nama_barang RIGHT JOIN stok_barang on stok_barang.nama_barang = stok_barang_lama.nama_barang WHERE month(stok_barang_lama.tanggal)='"+stok_lama+"' AND YEAR(stok_barang_lama.tanggal)='"+year+"' GROUP BY stok_barang_lama.no ";            
            stmt.executeUpdate(sqll);
            stmt.close();
            JOptionPane.showMessageDialog(rootPane,"Data Berhasil di Simpan. Silahkan Cetak Laporan");
            
        } catch (Exception e){
//            JOptionPane.showMessageDialog(null, e); 
        }
    }
    public void simpanSementara(){
        try{
            konek.config();
            DefaultTableModel dataModel = (DefaultTableModel) tabel_pemakaian.getModel();    
            stmt = konek.conn.createStatement();
            String sqll1 = "DELETE FROM laporan_sementara";
            stmt.executeUpdate(sqll1);   
            String sqll = "insert into laporan_sementara(no,nama_barang,stok_bulan_lalu,barang_masuk,tanggal,jumlah_pakai,sisa)SELECT stok_barang_lama.no,stok_barang_lama.nama_barang, stok_barang_lama.stok_barang,ifnull(temp_barang_masuk.jumlah,0),'"+tanggal+"' as tanggal,IFNULL(jumlah_pakai,0)as jumlah_pakai,stok_barang.jumlah as sisa FROM `hasil_pakai` RIGHT JOIN stok_barang_lama on stok_barang_lama.nama_barang = hasil_pakai.nama_barang RIGHT JOIN stok_barang on stok_barang.nama_barang = stok_barang_lama.nama_barang LEFT OUTER JOIN temp_barang_masuk on temp_barang_masuk.no = stok_barang.no WHERE month(stok_barang_lama.tanggal)='"+stok_lama+"' AND YEAR(stok_barang_lama.tanggal)='"+year+"' GROUP BY stok_barang_lama.no ";            
            stmt.executeUpdate(sqll);    
            stmt.close();
            } catch (Exception e){
        }
    }
    
    public void bersihkan(){
        DefaultTableModel dataModel = (DefaultTableModel) tabel_pemakaian.getModel();
        if (tabel_pemakaian.getRowCount()>0){
            for (int i = tabel_pemakaian.getRowCount() - 1; i> -1; i--){
                dataModel.removeRow(i);
            }
        }
    }
    public void cetakLaporan(){
        try{
            konek.config();
            String namaFile = "../src/Laporan/Rekap_Laporan_Keluar_Masuk.jrxml";
            Map mpr = new HashMap();
            JasperReport jrpt = JasperCompileManager.compileReport(namaFile);
            JasperPrint jp = JasperFillManager.fillReport(jrpt,mpr,konek.conn);
            JasperViewer.viewReport(jp,false);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_pemakaian = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txt_cari = new javax.swing.JTextField();
        btn_lihat = new javax.swing.JButton();
        btn_kembali = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txt_bulan = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txt_tahun = new com.toedter.calendar.JYearChooser();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btn_cetak_keluar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(192, 192, 192));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Pemakaian Barang", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 18))); // NOI18N

        tabel_pemakaian.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tabel_pemakaian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Tanggal", "Nama Barang", "Barang Masuk", "Jumlah Pakai", "Sisa"
            }
        ));
        jScrollPane1.setViewportView(tabel_pemakaian);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Cari");

        txt_cari.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        btn_lihat.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_lihat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Create.png"))); // NOI18N
        btn_lihat.setText("Lihat");
        btn_lihat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lihatActionPerformed(evt);
            }
        });

        btn_kembali.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_kembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/back.png"))); // NOI18N
        btn_kembali.setText("Kembali");
        btn_kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kembaliActionPerformed(evt);
            }
        });

        btn_save.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/save.png"))); // NOI18N
        btn_save.setText("Simpan");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_save, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_kembali, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                    .addComponent(btn_lihat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_cari))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txt_cari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btn_lihat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_kembali))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(192, 192, 192));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setText("Bulan");

        txt_bulan.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_bulan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
        txt_bulan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bulanActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setText("Tahun");

        txt_tahun.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(26, 26, 26)
                .addComponent(txt_bulan, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel4)
                .addGap(30, 30, 30)
                .addComponent(txt_tahun, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(232, 232, 232))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(txt_bulan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3))
                    .addComponent(txt_tahun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(75, 76, 202));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setText("Rekap Bulanan Barang");

        btn_cetak_keluar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_cetak_keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/print_40px.png"))); // NOI18N
        btn_cetak_keluar.setText("Cetak");
        btn_cetak_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cetak_keluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(147, 147, 147)
                .addComponent(btn_cetak_keluar)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(btn_cetak_keluar))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kembaliActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btn_kembaliActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:
        simpanLaporan();
        simpanStokLama();
        simpanSementara();
        simpanPersediaanBarang();
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_lihatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lihatActionPerformed
        // TODO add your handling code here:
        saveTempMasuk();
        lihatData();
    }//GEN-LAST:event_btn_lihatActionPerformed

    private void txt_bulanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bulanActionPerformed
        // TODO add your handling code here:
        initiateBulan();
    }//GEN-LAST:event_txt_bulanActionPerformed

    private void btn_cetak_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cetak_keluarActionPerformed
        // TODO add your handling code here:
        cetakLaporan();
    }//GEN-LAST:event_btn_cetak_keluarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RekapKeluarMasuk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RekapKeluarMasuk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RekapKeluarMasuk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RekapKeluarMasuk.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RekapKeluarMasuk().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cetak_keluar;
    private javax.swing.JButton btn_kembali;
    private javax.swing.JButton btn_lihat;
    private javax.swing.JButton btn_save;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabel_pemakaian;
    private javax.swing.JComboBox<String> txt_bulan;
    private javax.swing.JTextField txt_cari;
    private com.toedter.calendar.JYearChooser txt_tahun;
    // End of variables declaration//GEN-END:variables

    
}
