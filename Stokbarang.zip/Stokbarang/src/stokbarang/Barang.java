/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stokbarang;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author xLee
 */
public class Barang extends javax.swing.JFrame {
    koneksi konek = new koneksi();
    Statement stmt;
    ResultSet rs;
    ResultSetMetaData meta;
    SimpleDateFormat newtgl = new SimpleDateFormat("yyyy/MM/dd");
    String tanggal_keluar,tanggal_masuk,tanggal_stok,tanggal_laporan,tanggal,laporan;
    /**
     * Creates new form Barang
     */
    public Barang() {
        initComponents();
        refreshTable_stok();
        formatTanggal();
        setLocationRelativeTo(null);
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                handleClosing();
            }
        });
        disableHapus();
    }
    public void disableHapus(){
        if(tabel_barang_keluar.getRowCount() == 0){
            btn_delete_keluar.setEnabled(false);
        }else{
            btn_delete_keluar.setEnabled(true);
        }
        if(tabel_barang_masuk.getRowCount() == 0){
            btn_delete_masuk.setEnabled(false);
        }else{
            btn_delete_masuk.setEnabled(true);
        }
    }
    public void initiateBulan(){
        tanggal_stok ="";
        tanggal = txt_bulan_rekap_barang.getSelectedItem()+" "+txt_tahun_rekap_barang.getYear();
        switch(txt_bulan_stok_lama.getSelectedItem().toString()){
            case "Januari": 
                tanggal_stok = "01";
                break;
            case "Februari":
                tanggal_stok = "02";
                break;
            case "Maret":
                tanggal_stok = "03";
                break;
            case "April":
                tanggal_stok ="04";
                break;
            case "Mei":
                tanggal_stok = "05";
                break;
            case "Juni": 
                tanggal_stok = "06";
                break;
            case "Juli":
                tanggal_stok = "07";
                break;
            case "Agustus":
                tanggal_stok = "08";
                break;
            case "September":
                tanggal_stok = "09";
                break;
            case "Oktober":
                tanggal_stok = "10";
                break;
            case "November":
                tanggal_stok = "11";
                break;
            case "Desember":
                tanggal_stok = "12";
                break;
        }
        switch(txt_bulan_keluar.getSelectedItem().toString()){
            case "Januari": 
                tanggal_stok = "01";
                break;
            case "Februari":
                tanggal_stok = "02";
                break;
            case "Maret":
                tanggal_stok = "03";
                break;
            case "April":
                tanggal_stok ="04";
                break;
            case "Mei":
                tanggal_stok = "05";
                break;
            case "Juni": 
                tanggal_stok = "06";
                break;
            case "Juli":
                tanggal_stok = "07";
                break;
            case "Agustus":
                tanggal_stok = "08";
                break;
            case "September":
                tanggal_stok = "09";
                break;
            case "Oktober":
                tanggal_stok = "10";
                break;
            case "November":
                tanggal_stok = "11";
                break;
            case "Desember":
                tanggal_stok = "12";
                break;
        }
        switch(txt_bulan_masuk.getSelectedItem().toString()){
            case "Januari": 
                tanggal_stok = "01";
                break;
            case "Februari":
                tanggal_stok = "02";
                break;
            case "Maret":
                tanggal_stok = "03";
                break;
            case "April":
                tanggal_stok ="04";
                break;
            case "Mei":
                tanggal_stok = "05";
                break;
            case "Juni": 
                tanggal_stok = "06";
                break;
            case "Juli":
                tanggal_stok = "07";
                break;
            case "Agustus":
                tanggal_stok = "08";
                break;
            case "September":
                tanggal_stok = "09";
                break;
            case "Oktober":
                tanggal_stok = "10";
                break;
            case "November":
                tanggal_stok = "11";
                break;
            case "Desember":
                tanggal_stok = "12";
                break;
        }
    }
    public void formatTanggal(){
        txt_tanggal_keluar.setDateFormatString("yyyy/MM/dd");
        txt_tanggal_masuk.setDateFormatString("yyyy/MM/dd");
    }
    public void handleClosing(){
            int ok = JOptionPane.showConfirmDialog(null, "Apakah Yakin Ingin Keluar ?","Keluar",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
            if(ok==0){
            System.exit(0);
        }
    }
    public void refreshTable_stok(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from stok_barang order by no asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("nama_barang");
                dataTable[x][2]=rs.getString("jumlah");
                x++;
            }
            tabel_stok_barang.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void refreshTable_barang_masuk(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_masuk order by no,tanggal asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("jumlah");
                x++;
            }
            tabel_barang_masuk.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void refreshTable_barang_masuk_tanggal(){
        tanggal_masuk = String.valueOf(newtgl.format(txt_tanggal_masuk.getDate()));
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_masuk WHERE tanggal = '"+tanggal_masuk+"'order by no asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("jumlah");
                x++;
            }
            tabel_barang_masuk.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
        public void refreshTable_barang_masuk_bulan(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_masuk where month(tanggal)='"+tanggal_stok+"' AND year(tanggal)='"+txt_tahun_masuk.getYear()+"+' order by no,tanggal asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("jumlah");
                x++;
            }
            tabel_barang_masuk.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void refreshTable_barang_keluar(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_keluar order by no,tanggal asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("jumlah");
                x++;
            }
            tabel_barang_keluar.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void refreshTable_barang_keluar_tanggal(){
        tanggal_keluar = String.valueOf(newtgl.format(txt_tanggal_keluar.getDate()));
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_keluar WHERE tanggal ='"+tanggal_keluar+"' order by no asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("jumlah");
                x++;
            }
            tabel_barang_keluar.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void refreshTable_barang_keluar_bulan(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_keluar where month(tanggal)='"+tanggal_stok+"' AND year(tanggal)='"+txt_tahun_keluar.getYear()+"' order by no,tanggal asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getString("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("jumlah");
                x++;
            }
            tabel_barang_keluar.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void refreshTable_stok_lama(){
        try{
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from stok_barang_lama WHERE MONTH(tanggal)='"+tanggal_stok+"' && YEAR(tanggal)='"+txt_tahun_stok_lama.getYear()+"' order by no asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang","Stok Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while(rs.next()){
                brs = rs.getRow();
            }
            Object dataTable[][] =  new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while(rs.next()){
                dataTable[x][0]=rs.getInt("no");
                dataTable[x][1]=rs.getString("tanggal");
                dataTable[x][2]=rs.getString("nama_barang");
                dataTable[x][3]=rs.getString("stok_barang");
                x++;
            }
            tabel_stok_lama.setModel(new DefaultTableModel(dataTable,Header));
            stmtTable.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void refreshTable_laporan_keluar(){
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from pemakaian_barang WHERE tanggal LIKE '%"+tanggal+"%' order by no asc";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Nama Barang", "Stok Bulan Lalu","Barang Masuk","Tanggal","Jumlah Pakai","Sisa"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getString("no");
                dataTable[x][1] = rs.getString("nama_barang");
                dataTable[x][2] = rs.getString("stok_bulan_lalu");
                dataTable[x][3] = rs.getString("barang_masuk");
                dataTable[x][4] = rs.getString("tanggal");
                dataTable[x][5] = rs.getString("jumlah_pakai");
                dataTable[x][6] = rs.getString("sisa");
                x++;
            }
            tabel_laporan_keluar.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void cariBarang(){
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from stok_barang WHERE nama_barang LIKE'%" + txt_cari_barang.getText() + "%' OR no LIKE '%"+txt_cari_barang.getText()+"%'";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Nama Barang", "Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getString("no");
                dataTable[x][1] = rs.getString("nama_barang");
                dataTable[x][2] = rs.getString("jumlah");
                x++;
            }
            tabel_stok_barang.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void cariBarangKeluar(){
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_keluar WHERE nama_barang LIKE'%" + txt_cari_barang_keluar.getText() + "%' OR tanggal like '"+txt_cari_barang_keluar.getText()+"' OR no LIKE '%"+txt_cari_barang_keluar.getText()+"%'";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang", "Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getString("no");
                dataTable[x][1] = rs.getString("tanggal");
                dataTable[x][2] = rs.getString("nama_barang");
                dataTable[x][3] = rs.getString("jumlah");
                x++;
            }
            tabel_barang_keluar.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void cariBarangMasuk(){
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from barang_masuk WHERE nama_barang LIKE'%" + txt_cari_barang_masuk.getText() + "%' OR tanggal LIKE '%"+txt_cari_barang_masuk.getText()+"%' OR no LIKE '%"+txt_cari_barang_masuk.getText()+"%' ";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Tanggal","Nama Barang", "Jumlah Barang"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getString("no");
                dataTable[x][1] = rs.getString("tanggal");
                dataTable[x][2] = rs.getString("nama_barang");
                dataTable[x][3] = rs.getString("jumlah");
                x++;
            }
            tabel_barang_masuk.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void cariBarangStokLama(){
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from pemakaian_barang WHERE nama_barang LIKE'%" + txt_cari_barang_stok_lama.getText() + "%' OR tanggal LIKE '%"+txt_cari_barang_stok_lama.getText()+"%' OR no LIKE '%"+txt_cari_barang_stok_lama.getText()+"%'";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Nama Barang", "Stok Bulan Lalu","Tanggal","Jumlah Pakai","Sisa"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getString("no");
                dataTable[x][1] = rs.getString("nama_barang");
                dataTable[x][2] = rs.getString("stok_bulan_lalu");
                dataTable[x][3] = rs.getString("tanggal");
                dataTable[x][4] = rs.getString("jumlah_pakai");
                dataTable[x][5] = rs.getString("sisa");
                x++;
            }
            tabel_laporan_keluar.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void cariLaporan_Keluar(){
        try {
            konek.config();
            Statement stmtTable = konek.conn.createStatement();
            String sql = "select * from pemakaian_barang WHERE nama_barang LIKE'%" + txt_cari_laporan_keluar.getText() + "%' OR tanggal LIKE '%"+txt_cari_laporan_keluar.getText()+"%' OR no LIKE '%"+txt_cari_laporan_keluar.getText()+"%' ";
            rs = stmtTable.executeQuery(sql);
            meta = rs.getMetaData();
            String Header[] = {"No","Nama Barang", "Stok Bulan Lalu","Barang Masuk","Tanggal","Jumlah Pakai","Sisa"};
            int col = meta.getColumnCount();
            int brs = 0;
            while (rs.next()) {
                brs = rs.getRow();
            }
            Object dataTable[][] = new Object[brs][col];
            int x = 0;
            rs.beforeFirst();
            while (rs.next()) {
                dataTable[x][0] = rs.getString("no");
                dataTable[x][1] = rs.getString("nama_barang");
                dataTable[x][2] = rs.getString("stok_bulan_lalu");
                dataTable[x][3] = rs.getString("barang_masuk");
                dataTable[x][4] = rs.getString("tanggal");
                dataTable[x][5] = rs.getString("jumlah_pakai");
                dataTable[x][6] = rs.getString("sisa");
                x++;
            }
            tabel_laporan_keluar.setModel(new DefaultTableModel(dataTable, Header));
            stmtTable.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void deleteDataKeluar(){
        try{
            DefaultTableModel model = (DefaultTableModel) tabel_barang_keluar.getModel();
            int row = tabel_barang_keluar.getSelectedRow();
            if(row >= 0){
                int ok=JOptionPane.showConfirmDialog(null, "Anda Yakin ingin di Hapus?","Hapus Data",JOptionPane.YES_NO_OPTION);
                if(ok == 0){
                    konek.config();
                    stmt = konek.conn.createStatement();
                    String sqlkeluar= "delete from barang_keluar where no = '"+((String)model.getValueAt(row,0))+"' AND tanggal = '"+((String)model.getValueAt(row,1))+"' ";
                    stmt.executeUpdate(sqlkeluar);
                }
            } 

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void deleteDataMasuk(){
        try{
            DefaultTableModel model = (DefaultTableModel) tabel_barang_masuk.getModel();
            int row = tabel_barang_masuk.getSelectedRow();
            if(row >= 0){
                int ok=JOptionPane.showConfirmDialog(null, "Anda Yakin ingin di Hapus?","Hapus Data",JOptionPane.YES_NO_OPTION);
                if(ok == 0){
                    konek.config();
                    stmt = konek.conn.createStatement();
                    String sqlkeluar= "delete from barang_masuk where no = '"+((String)model.getValueAt(row,0))+"' AND tanggal = '"+((String)model.getValueAt(row,1))+"' ";
                    stmt.executeUpdate(sqlkeluar);
                }
            } 

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void deleteRekapData(){
        try{
            
        }catch(Exception e ){
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
    }
    
    public void cetakLaporan(){
        try{
            String namaFile ="";
            switch(laporan){
                case "masuk" : namaFile = "../src/Laporan/Barang_Masuk.jrxml";
                break;
                case "keluar": namaFile = "../src/Laporan/Barang_Keluar.jrxml";
                break;
                case "pengaduan": namaFile = "../src/Laporan/Pengaduan.jrxml";
                break;
            }
            konek.config();
            Map mpr = new HashMap();
            JasperReport jrpt = JasperCompileManager.compileReport(namaFile);
            JasperPrint jp = JasperFillManager.fillReport(jrpt,mpr,konek.conn);
            JasperViewer.viewReport(jp,false);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_stok_barang = new javax.swing.JTable();
        btn_refresh = new javax.swing.JButton();
        txt_cari_barang = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel_barang_keluar = new javax.swing.JTable();
        btn_refresh_keluar = new javax.swing.JButton();
        Cari = new javax.swing.JLabel();
        txt_cari_barang_keluar = new javax.swing.JTextField();
        txt_tanggal_keluar = new com.toedter.calendar.JDateChooser();
        btn_delete_keluar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txt_bulan_keluar = new javax.swing.JComboBox<>();
        txt_tahun_keluar = new com.toedter.calendar.JYearChooser();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabel_barang_masuk = new javax.swing.JTable();
        btn_refresh_masuk = new javax.swing.JButton();
        txt_cari_barang_masuk = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_tanggal_masuk = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        btn_delete_masuk = new javax.swing.JButton();
        txt_bulan_masuk = new javax.swing.JComboBox<>();
        txt_tahun_masuk = new com.toedter.calendar.JYearChooser();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabel_stok_lama = new javax.swing.JTable();
        btn_refresh_stok_lama = new javax.swing.JButton();
        txt_cari_barang_stok_lama = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txt_bulan_stok_lama = new javax.swing.JComboBox<>();
        txt_tahun_stok_lama = new com.toedter.calendar.JYearChooser();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabel_laporan_keluar = new javax.swing.JTable();
        btn_refresh_laporan_keluar = new javax.swing.JButton();
        txt_cari_laporan_keluar = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_bulan_rekap_barang = new javax.swing.JComboBox<>();
        txt_tahun_rekap_barang = new com.toedter.calendar.JYearChooser();
        jPanel8 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menu_exit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        menu_barang_masuk = new javax.swing.JMenuItem();
        menu_barang_keluar = new javax.swing.JMenuItem();
        menu_tambah_barang = new javax.swing.JMenuItem();
        menu_pengaduan = new javax.swing.JMenuItem();
        menu_laporan = new javax.swing.JMenu();
        laporan_keluar = new javax.swing.JMenuItem();
        laporan_masuk = new javax.swing.JMenuItem();
        laporan_pengaduan = new javax.swing.JMenuItem();
        laporan_barang = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jTabbedPane1.setBackground(new java.awt.Color(192, 192, 192));
        jTabbedPane1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(192, 192, 192));

        tabel_stok_barang.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tabel_stok_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Nama Barang", "Jumlah Barang"
            }
        ));
        jScrollPane1.setViewportView(tabel_stok_barang);
        if (tabel_stok_barang.getColumnModel().getColumnCount() > 0) {
            tabel_stok_barang.getColumnModel().getColumn(0).setPreferredWidth(5);
        }

        btn_refresh.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_refresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btn_refresh.setText("Muat Ulang Tabel");
        btn_refresh.setToolTipText("");
        btn_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refreshActionPerformed(evt);
            }
        });

        txt_cari_barang.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txt_cari_barang.setMargin(new java.awt.Insets(3, 3, 3, 3));
        txt_cari_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cari_barangActionPerformed(evt);
            }
        });
        txt_cari_barang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cari_barangKeyReleased(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("Cari");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(btn_refresh))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(txt_cari_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(177, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_cari_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_refresh)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Data Barang", jPanel1);

        jPanel4.setBackground(new java.awt.Color(192, 192, 192));

        tabel_barang_keluar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tabel_barang_keluar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Tanggal", "Nama Barang", "Jumlah Barang"
            }
        ));
        jScrollPane2.setViewportView(tabel_barang_keluar);
        if (tabel_barang_keluar.getColumnModel().getColumnCount() > 0) {
            tabel_barang_keluar.getColumnModel().getColumn(0).setPreferredWidth(5);
        }

        btn_refresh_keluar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_refresh_keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btn_refresh_keluar.setText("Lihat Semua Data");
        btn_refresh_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refresh_keluarActionPerformed(evt);
            }
        });

        Cari.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Cari.setText("Cari");

        txt_cari_barang_keluar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txt_cari_barang_keluar.setMargin(new java.awt.Insets(3, 3, 3, 3));
        txt_cari_barang_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cari_barang_keluarActionPerformed(evt);
            }
        });
        txt_cari_barang_keluar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cari_barang_keluarKeyReleased(evt);
            }
        });

        txt_tanggal_keluar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_tanggal_keluar.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_tanggal_keluarPropertyChange(evt);
            }
        });

        btn_delete_keluar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_delete_keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8_Delete_Document_30px.png"))); // NOI18N
        btn_delete_keluar.setText("Hapus");
        btn_delete_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_keluarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Tanggal");

        txt_bulan_keluar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_bulan_keluar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
        txt_bulan_keluar.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txt_bulan_keluarItemStateChanged(evt);
            }
        });
        txt_bulan_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bulan_keluarActionPerformed(evt);
            }
        });

        txt_tahun_keluar.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_tahun_keluarPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(Cari)
                        .addGap(18, 18, 18)
                        .addComponent(txt_cari_barang_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(txt_tanggal_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btn_refresh_keluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_delete_keluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(txt_bulan_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_tahun_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(149, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_tanggal_keluar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txt_cari_barang_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7)
                                .addComponent(Cari))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_tahun_keluar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_bulan_keluar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(btn_refresh_keluar)
                        .addGap(18, 18, 18)
                        .addComponent(btn_delete_keluar))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Data Barang Keluar", jPanel4);

        jPanel3.setBackground(new java.awt.Color(192, 192, 192));

        tabel_barang_masuk.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tabel_barang_masuk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Tanggal", "Nama Barang", "Jumlah Barang"
            }
        ));
        jScrollPane3.setViewportView(tabel_barang_masuk);
        if (tabel_barang_masuk.getColumnModel().getColumnCount() > 0) {
            tabel_barang_masuk.getColumnModel().getColumn(0).setPreferredWidth(5);
        }

        btn_refresh_masuk.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_refresh_masuk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btn_refresh_masuk.setText("Lihat Semua Data");
        btn_refresh_masuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refresh_masukActionPerformed(evt);
            }
        });

        txt_cari_barang_masuk.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txt_cari_barang_masuk.setMargin(new java.awt.Insets(3, 3, 3, 3));
        txt_cari_barang_masuk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cari_barang_masukKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("Cari");

        txt_tanggal_masuk.setFocusable(false);
        txt_tanggal_masuk.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_tanggal_masuk.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_tanggal_masukPropertyChange(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Tanggal");

        btn_delete_masuk.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_delete_masuk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8_Delete_Document_30px.png"))); // NOI18N
        btn_delete_masuk.setText("Hapus");
        btn_delete_masuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_masukActionPerformed(evt);
            }
        });

        txt_bulan_masuk.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_bulan_masuk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
        txt_bulan_masuk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txt_bulan_masukItemStateChanged(evt);
            }
        });
        txt_bulan_masuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bulan_masukActionPerformed(evt);
            }
        });

        txt_tahun_masuk.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_tahun_masukPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(txt_cari_barang_masuk, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txt_tanggal_masuk, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(55, 55, 55)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(txt_bulan_masuk, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_tahun_masuk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btn_refresh_masuk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_delete_masuk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(149, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(txt_cari_barang_masuk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addComponent(txt_tanggal_masuk, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_bulan_masuk)
                    .addComponent(txt_tahun_masuk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(7, 7, 7)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btn_refresh_masuk)
                        .addGap(18, 18, 18)
                        .addComponent(btn_delete_masuk)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Data Barang Masuk", jPanel3);

        jPanel5.setBackground(new java.awt.Color(192, 192, 192));

        tabel_stok_lama.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tabel_stok_lama.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Tanggal", "Nama Barang", "Stok Barang"
            }
        ));
        jScrollPane4.setViewportView(tabel_stok_lama);

        btn_refresh_stok_lama.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_refresh_stok_lama.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btn_refresh_stok_lama.setText("Muat Ulang Tabel");
        btn_refresh_stok_lama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refresh_stok_lamaActionPerformed(evt);
            }
        });

        txt_cari_barang_stok_lama.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txt_cari_barang_stok_lama.setMargin(new java.awt.Insets(3, 3, 3, 3));
        txt_cari_barang_stok_lama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cari_barang_stok_lamaKeyReleased(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Cari");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Tanggal");

        txt_bulan_stok_lama.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_bulan_stok_lama.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
        txt_bulan_stok_lama.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txt_bulan_stok_lamaItemStateChanged(evt);
            }
        });

        txt_tahun_stok_lama.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txt_tahun_stok_lama.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_tahun_stok_lamaPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(btn_refresh_stok_lama))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txt_cari_barang_stok_lama, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(txt_bulan_stok_lama, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_tahun_stok_lama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(177, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_tahun_stok_lama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(txt_cari_barang_stok_lama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)
                        .addComponent(txt_bulan_stok_lama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(7, 7, 7)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_refresh_stok_lama))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Stok Bulan Sebelumnya", jPanel2);

        jPanel7.setBackground(new java.awt.Color(192, 192, 192));

        tabel_laporan_keluar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tabel_laporan_keluar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Nama Barang", "Stok Bulan Lalu", "Barang Masuk", "Tanggal", "Jumlah Pakai", "Sisa"
            }
        ));
        jScrollPane5.setViewportView(tabel_laporan_keluar);

        btn_refresh_laporan_keluar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_refresh_laporan_keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btn_refresh_laporan_keluar.setText("Muat Ulang Tabel");
        btn_refresh_laporan_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refresh_laporan_keluarActionPerformed(evt);
            }
        });

        txt_cari_laporan_keluar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txt_cari_laporan_keluar.setMargin(new java.awt.Insets(3, 3, 3, 3));
        txt_cari_laporan_keluar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cari_laporan_keluarKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Cari");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setText("Tanggal");

        txt_bulan_rekap_barang.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txt_bulan_rekap_barang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
        txt_bulan_rekap_barang.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txt_bulan_rekap_barangItemStateChanged(evt);
            }
        });
        txt_bulan_rekap_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bulan_rekap_barangActionPerformed(evt);
            }
        });

        txt_tahun_rekap_barang.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txt_tahun_rekap_barang.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_tahun_rekap_barangPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 647, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(btn_refresh_laporan_keluar))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txt_cari_laporan_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(txt_bulan_rekap_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_tahun_rekap_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(txt_cari_laporan_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(txt_bulan_rekap_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txt_tahun_rekap_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_refresh_laporan_keluar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Rekap Bulanan", jPanel6);

        jPanel8.setBackground(new java.awt.Color(75, 76, 202));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setText("Inventory Barang UPT PJU Depok");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(283, 283, 283)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jMenuBar1.setBackground(new java.awt.Color(192, 192, 192));

        jMenu1.setText("File");
        jMenu1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        menu_exit.setText("Exit");
        menu_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_exitActionPerformed(evt);
            }
        });
        jMenu1.add(menu_exit);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Master");

        menu_barang_masuk.setText("Barang Masuk");
        menu_barang_masuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_barang_masukActionPerformed(evt);
            }
        });
        jMenu2.add(menu_barang_masuk);

        menu_barang_keluar.setText("Barang Keluar");
        menu_barang_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_barang_keluarActionPerformed(evt);
            }
        });
        jMenu2.add(menu_barang_keluar);

        menu_tambah_barang.setText("Tambah Barang");
        menu_tambah_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_tambah_barangActionPerformed(evt);
            }
        });
        jMenu2.add(menu_tambah_barang);

        menu_pengaduan.setText("Pengaduan");
        menu_pengaduan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_pengaduanActionPerformed(evt);
            }
        });
        jMenu2.add(menu_pengaduan);

        jMenuBar1.add(jMenu2);

        menu_laporan.setText("Laporan");
        menu_laporan.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        menu_laporan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_laporanActionPerformed(evt);
            }
        });

        laporan_keluar.setText("Cetak Laporan Barang Keluar");
        laporan_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laporan_keluarActionPerformed(evt);
            }
        });
        menu_laporan.add(laporan_keluar);

        laporan_masuk.setText("Cetak Laporan Barang Masuk");
        laporan_masuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laporan_masukActionPerformed(evt);
            }
        });
        menu_laporan.add(laporan_masuk);

        laporan_pengaduan.setText("Cetak Laporan Pengaduan");
        laporan_pengaduan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laporan_pengaduanActionPerformed(evt);
            }
        });
        menu_laporan.add(laporan_pengaduan);

        laporan_barang.setText("Buat Laporan Bulanan");
        laporan_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laporan_barangActionPerformed(evt);
            }
        });
        menu_laporan.add(laporan_barang);

        jMenuBar1.add(menu_laporan);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jTabbedPane1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menu_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_exitActionPerformed
        // TODO add your handling code here:
        int ok = JOptionPane.showConfirmDialog(null, "Apakah Yakin Ingin Keluar ?","Keluar",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        if(ok==0){
            System.exit(0);
        }
    }//GEN-LAST:event_menu_exitActionPerformed

    private void menu_barang_masukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_barang_masukActionPerformed
        // TODO add your handling code here:
        BarangMasuk barangMasuk = new BarangMasuk();
        barangMasuk.setVisible(true);
    }//GEN-LAST:event_menu_barang_masukActionPerformed

    private void menu_barang_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_barang_keluarActionPerformed
        // TODO add your handling code here:
        BarangKeluar barangKeluar = new BarangKeluar();
        barangKeluar.setVisible(true);
    }//GEN-LAST:event_menu_barang_keluarActionPerformed

    private void btn_refresh_masukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refresh_masukActionPerformed
        // TODO add your handling code here:
        refreshTable_barang_masuk();
          disableHapus();
    }//GEN-LAST:event_btn_refresh_masukActionPerformed

    private void btn_refresh_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refresh_keluarActionPerformed
        // TODO add your handling code here:
        refreshTable_barang_keluar();
          disableHapus();
    }//GEN-LAST:event_btn_refresh_keluarActionPerformed

    private void btn_refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refreshActionPerformed
        // TODO add your handling code here:
        refreshTable_stok();
    }//GEN-LAST:event_btn_refreshActionPerformed

    private void menu_tambah_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_tambah_barangActionPerformed
        // TODO add your handling code here:
        TambahBarang tambahBarang = new TambahBarang();
        tambahBarang.setVisible(true);
    }//GEN-LAST:event_menu_tambah_barangActionPerformed

    private void txt_cari_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cari_barangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_cari_barangActionPerformed

    private void txt_cari_barang_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cari_barang_keluarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_cari_barang_keluarActionPerformed

    private void txt_cari_barangKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cari_barangKeyReleased
        // TODO add your handling code here:
        cariBarang();
    }//GEN-LAST:event_txt_cari_barangKeyReleased

    private void txt_cari_barang_keluarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cari_barang_keluarKeyReleased
        // TODO add your handling code here:
        cariBarangKeluar();
    }//GEN-LAST:event_txt_cari_barang_keluarKeyReleased

    private void txt_cari_barang_masukKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cari_barang_masukKeyReleased
        // TODO add your handling code here:
        cariBarangMasuk();
    }//GEN-LAST:event_txt_cari_barang_masukKeyReleased

    private void menu_laporanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_laporanActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_menu_laporanActionPerformed

    private void btn_refresh_stok_lamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refresh_stok_lamaActionPerformed
        // TODO add your handling code here:
        refreshTable_stok_lama();
    }//GEN-LAST:event_btn_refresh_stok_lamaActionPerformed

    private void txt_cari_barang_stok_lamaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cari_barang_stok_lamaKeyReleased
        // TODO add your handling code here:
        cariBarangStokLama();
    }//GEN-LAST:event_txt_cari_barang_stok_lamaKeyReleased

    private void btn_refresh_laporan_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refresh_laporan_keluarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_refresh_laporan_keluarActionPerformed

    private void txt_cari_laporan_keluarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cari_laporan_keluarKeyReleased
        // TODO add your handling code here:
        cariLaporan_Keluar();
    }//GEN-LAST:event_txt_cari_laporan_keluarKeyReleased

    private void btn_delete_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_keluarActionPerformed
        // TODO add your handling code here:
        deleteDataKeluar();
        if(txt_tanggal_keluar.getDate() != null && tabel_barang_keluar.getRowCount()>=1){
            refreshTable_barang_keluar_tanggal();
            refreshTable_stok();
        }else{
            refreshTable_barang_keluar();
            refreshTable_stok();
        }
    }//GEN-LAST:event_btn_delete_keluarActionPerformed

    private void txt_tanggal_keluarPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_tanggal_keluarPropertyChange
        // TODO add your handling code here:
        if(txt_tanggal_keluar.getDate() != null){
            refreshTable_barang_keluar_tanggal();
            disableHapus();
        }
    }//GEN-LAST:event_txt_tanggal_keluarPropertyChange

    private void txt_tanggal_masukPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_tanggal_masukPropertyChange
        // TODO add your handling code here:
        if(txt_tanggal_masuk.getDate() != null){
            refreshTable_barang_masuk_tanggal();
              disableHapus();
        }
    }//GEN-LAST:event_txt_tanggal_masukPropertyChange

    private void btn_delete_masukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_masukActionPerformed
        // TODO add your handling code here:
        deleteDataMasuk();
        if(txt_tanggal_masuk.getDate() != null && tabel_barang_masuk.getRowCount()>=1){
            refreshTable_barang_masuk_tanggal();
            refreshTable_stok();
        }else{
            refreshTable_barang_masuk();
            refreshTable_stok();
        }
    }//GEN-LAST:event_btn_delete_masukActionPerformed

    private void txt_bulan_stok_lamaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txt_bulan_stok_lamaItemStateChanged
        // TODO add your handling code here:
        initiateBulan();
        refreshTable_stok_lama();
    }//GEN-LAST:event_txt_bulan_stok_lamaItemStateChanged

    private void txt_tahun_stok_lamaPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_tahun_stok_lamaPropertyChange
        // TODO add your handling code here:
        refreshTable_stok_lama();
    }//GEN-LAST:event_txt_tahun_stok_lamaPropertyChange

    private void txt_tahun_rekap_barangPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_tahun_rekap_barangPropertyChange
        // TODO add your handling code here:
        initiateBulan();
        refreshTable_laporan_keluar();
    }//GEN-LAST:event_txt_tahun_rekap_barangPropertyChange

    private void txt_bulan_rekap_barangItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txt_bulan_rekap_barangItemStateChanged
        // TODO add your handling code here:
        initiateBulan();
        refreshTable_laporan_keluar();
    }//GEN-LAST:event_txt_bulan_rekap_barangItemStateChanged

    private void laporan_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laporan_barangActionPerformed
        // TODO add your handling code here:
        RekapKeluarMasuk rekapKeluarMasuk = new RekapKeluarMasuk();
        rekapKeluarMasuk.setVisible(true);
    }//GEN-LAST:event_laporan_barangActionPerformed

    private void txt_bulan_rekap_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bulan_rekap_barangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_bulan_rekap_barangActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jMenu1ActionPerformed

    private void txt_bulan_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bulan_keluarActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_bulan_keluarActionPerformed

    private void txt_bulan_masukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bulan_masukActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_bulan_masukActionPerformed

    private void txt_bulan_masukItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txt_bulan_masukItemStateChanged
        // TODO add your handling code here:
        txt_tanggal_masuk.setCalendar(null);
        initiateBulan();
        refreshTable_barang_masuk_bulan();
          disableHapus();
    }//GEN-LAST:event_txt_bulan_masukItemStateChanged

    private void txt_bulan_keluarItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txt_bulan_keluarItemStateChanged
        // TODO add your handling code here:
        txt_tanggal_keluar.setCalendar(null);
        initiateBulan();
        refreshTable_barang_keluar_bulan();
          disableHapus();
    }//GEN-LAST:event_txt_bulan_keluarItemStateChanged

    private void txt_tahun_masukPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_tahun_masukPropertyChange
        // TODO add your handling code here:
        txt_tanggal_masuk.setCalendar(null);
        initiateBulan();
        refreshTable_barang_masuk_bulan();
          disableHapus();
    }//GEN-LAST:event_txt_tahun_masukPropertyChange

    private void txt_tahun_keluarPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_tahun_keluarPropertyChange
        // TODO add your handling code here:
        txt_tanggal_keluar.setCalendar(null);
        initiateBulan();
        refreshTable_barang_keluar_bulan();
          disableHapus();
    }//GEN-LAST:event_txt_tahun_keluarPropertyChange

    private void menu_pengaduanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_pengaduanActionPerformed
        // TODO add your handling code here:
        Pengaduan pengaduan = new Pengaduan();
        pengaduan.setVisible(true);
    }//GEN-LAST:event_menu_pengaduanActionPerformed

    private void laporan_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laporan_keluarActionPerformed
        // TODO add your handling code here:
        laporan = "keluar";
        cetakLaporan();
    }//GEN-LAST:event_laporan_keluarActionPerformed

    private void laporan_pengaduanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laporan_pengaduanActionPerformed
        // TODO add your handling code here:
        laporan = "pengaduan";
        cetakLaporan();
    }//GEN-LAST:event_laporan_pengaduanActionPerformed

    private void laporan_masukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laporan_masukActionPerformed
        // TODO add your handling code here:
        laporan = "masuk";
        cetakLaporan();
    }//GEN-LAST:event_laporan_masukActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Barang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Cari;
    private javax.swing.JButton btn_delete_keluar;
    private javax.swing.JButton btn_delete_masuk;
    private javax.swing.JButton btn_refresh;
    private javax.swing.JButton btn_refresh_keluar;
    private javax.swing.JButton btn_refresh_laporan_keluar;
    private javax.swing.JButton btn_refresh_masuk;
    private javax.swing.JButton btn_refresh_stok_lama;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JMenuItem laporan_barang;
    private javax.swing.JMenuItem laporan_keluar;
    private javax.swing.JMenuItem laporan_masuk;
    private javax.swing.JMenuItem laporan_pengaduan;
    private javax.swing.JMenuItem menu_barang_keluar;
    private javax.swing.JMenuItem menu_barang_masuk;
    private javax.swing.JMenuItem menu_exit;
    private javax.swing.JMenu menu_laporan;
    private javax.swing.JMenuItem menu_pengaduan;
    private javax.swing.JMenuItem menu_tambah_barang;
    private javax.swing.JTable tabel_barang_keluar;
    private javax.swing.JTable tabel_barang_masuk;
    private javax.swing.JTable tabel_laporan_keluar;
    private javax.swing.JTable tabel_stok_barang;
    private javax.swing.JTable tabel_stok_lama;
    private javax.swing.JComboBox<String> txt_bulan_keluar;
    private javax.swing.JComboBox<String> txt_bulan_masuk;
    private javax.swing.JComboBox<String> txt_bulan_rekap_barang;
    private javax.swing.JComboBox<String> txt_bulan_stok_lama;
    private javax.swing.JTextField txt_cari_barang;
    private javax.swing.JTextField txt_cari_barang_keluar;
    private javax.swing.JTextField txt_cari_barang_masuk;
    private javax.swing.JTextField txt_cari_barang_stok_lama;
    private javax.swing.JTextField txt_cari_laporan_keluar;
    private com.toedter.calendar.JYearChooser txt_tahun_keluar;
    private com.toedter.calendar.JYearChooser txt_tahun_masuk;
    private com.toedter.calendar.JYearChooser txt_tahun_rekap_barang;
    private com.toedter.calendar.JYearChooser txt_tahun_stok_lama;
    private com.toedter.calendar.JDateChooser txt_tanggal_keluar;
    private com.toedter.calendar.JDateChooser txt_tanggal_masuk;
    // End of variables declaration//GEN-END:variables
}
