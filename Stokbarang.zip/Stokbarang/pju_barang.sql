-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2020 at 03:10 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pju_barang`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user`, `password`) VALUES
('admin', '008'),
('uptpjudepok', 'pju12345');

-- --------------------------------------------------------

--
-- Table structure for table `barang_keluar`
--

CREATE TABLE `barang_keluar` (
  `no` int(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang_keluar`
--

INSERT INTO `barang_keluar` (`no`, `tanggal`, `nama_barang`, `jumlah`) VALUES
(1, '2020/01/06', 'Lampu Son T 250 Watt', '9.0'),
(3, '2020/01/06', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/01/06', 'Ballast SON 250 Watt', '10.0'),
(7, '2020/01/06', 'Ballast SON 70 Watt', '7.0'),
(9, '2020/01/06', 'Ignitor SN 58', '17.0'),
(10, '2020/01/06', 'Timer', '2.0'),
(15, '2020/01/06', 'MCB 16 A', '2.0'),
(22, '2020/01/06', 'Fotocell 6 A', '2.0'),
(27, '2020/01/06', 'Twisted Cable 2x10mm', '200.0'),
(1, '2020/01/07', 'Lampu Son T 250 Watt', '14.0'),
(3, '2020/01/07', 'Lampu Son T 70 Watt', '4.0'),
(5, '2020/01/07', 'Ballast SON 250 Watt', '14.0'),
(7, '2020/01/07', 'Ballast SON 70 Watt', '9.0'),
(9, '2020/01/07', 'Ignitor SN 58', '10.0'),
(15, '2020/01/07', 'MCB 16 A', '2.0'),
(22, '2020/01/07', 'Fotocell 6 A', '6.0'),
(26, '2020/01/07', 'Fitting E 40', '3.0'),
(33, '2020/01/07', 'Isolasi', '1.0'),
(35, '2020/01/07', 'Stanless', '1.0'),
(36, '2020/01/07', 'Weid Clamp', '5.0'),
(41, '2020/01/07', 'Stoping', '6.0'),
(66, '2020/01/07', 'Stang 2 x 1.5\"', '1.0'),
(1, '2020/01/08', 'Lampu Son T 250 Watt', '3.0'),
(3, '2020/01/08', 'Lampu Son T 70 Watt', '4.0'),
(5, '2020/01/08', 'Ballast SON 250 Watt', '4.0'),
(7, '2020/01/08', 'Ballast SON 70 Watt', '7.0'),
(9, '2020/01/08', 'Ignitor SN 58', '16.0'),
(15, '2020/01/08', 'MCB 16 A', '2.0'),
(33, '2020/01/08', 'Isolasi', '2.0'),
(1, '2020/01/09', 'Lampu Son T 250 Watt', '6.0'),
(3, '2020/01/09', 'Lampu Son T 70 Watt', '6.0'),
(5, '2020/01/09', 'Ballast SON 250 Watt', '7.0'),
(7, '2020/01/09', 'Ballast SON 70 Watt', '10.0'),
(9, '2020/01/09', 'Ignitor SN 58', '20.0'),
(22, '2020/01/09', 'Fotocell 6 A', '1.0'),
(29, '2020/01/09', 'Kabel NYM 500 V 2x1.5mm', '1.4'),
(1, '2020/01/10', 'Lampu Son T 250 Watt', '13.0'),
(3, '2020/01/10', 'Lampu Son T 70 Watt', '6.0'),
(5, '2020/01/10', 'Ballast SON 250 Watt', '12.0'),
(7, '2020/01/10', 'Ballast SON 70 Watt', '11.0'),
(9, '2020/01/10', 'Ignitor SN 58', '22.0'),
(15, '2020/01/10', 'MCB 16 A', '2.0'),
(22, '2020/01/10', 'Fotocell 6 A', '5.0'),
(29, '2020/01/10', 'Kabel NYM 500 V 2x1.5mm', '0.9'),
(36, '2020/01/10', 'Weid Clamp', '3.0'),
(1, '2020/01/11', 'Lampu Son T 250 Watt', '5.0'),
(3, '2020/01/11', 'Lampu Son T 70 Watt', '3.0'),
(5, '2020/01/11', 'Ballast SON 250 Watt', '5.0'),
(7, '2020/01/11', 'Ballast SON 70 Watt', '3.0'),
(9, '2020/01/11', 'Ignitor SN 58', '6.0'),
(15, '2020/01/11', 'MCB 16 A', '2.0'),
(17, '2020/01/11', 'MCB 50 A/1 Phase', '2.0'),
(24, '2020/01/11', 'Connector', '4.0'),
(36, '2020/01/11', 'Weid Clamp', '3.0'),
(1, '2020/01/13', 'Lampu Son T 250 Watt', '3.0'),
(3, '2020/01/13', 'Lampu Son T 70 Watt', '6.0'),
(5, '2020/01/13', 'Ballast SON 250 Watt', '4.0'),
(7, '2020/01/13', 'Ballast SON 70 Watt', '2.0'),
(9, '2020/01/13', 'Ignitor SN 58', '7.0'),
(15, '2020/01/13', 'MCB 16 A', '2.0'),
(22, '2020/01/13', 'Fotocell 6 A', '2.0'),
(24, '2020/01/13', 'Connector', '6.0'),
(26, '2020/01/13', 'Fitting E 40', '2.0'),
(33, '2020/01/13', 'Isolasi', '1.0'),
(1, '2020/01/14', 'Lampu Son T 250 Watt', '7.0'),
(3, '2020/01/14', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/01/14', 'Ballast SON 250 Watt', '8.0'),
(7, '2020/01/14', 'Ballast SON 70 Watt', '11.0'),
(9, '2020/01/14', 'Ignitor SN 58', '15.0'),
(15, '2020/01/14', 'MCB 16 A', '2.0'),
(22, '2020/01/14', 'Fotocell 6 A', '3.0'),
(27, '2020/01/14', 'Twisted Cable 2x10mm', '200.0'),
(33, '2020/01/14', 'Isolasi', '1.0'),
(36, '2020/01/14', 'Weid Clamp', '6.0'),
(1, '2020/01/15', 'Lampu Son T 250 Watt', '12.0'),
(3, '2020/01/15', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/01/15', 'Ballast SON 250 Watt', '12.0'),
(7, '2020/01/15', 'Ballast SON 70 Watt', '6.0'),
(9, '2020/01/15', 'Ignitor SN 58', '10.0'),
(17, '2020/01/15', 'MCB 50 A/1 Phase', '3.0'),
(22, '2020/01/15', 'Fotocell 6 A', '4.0'),
(24, '2020/01/15', 'Connector', '8.0'),
(26, '2020/01/15', 'Fitting E 40', '5.0'),
(27, '2020/01/15', 'Twisted Cable 2x10mm', '100.0'),
(29, '2020/01/15', 'Kabel NYM 500 V 2x1.5mm', '1.0'),
(33, '2020/01/15', 'Isolasi', '1.0'),
(36, '2020/01/15', 'Weid Clamp', '8.0'),
(28, '2020/01/15', 'Twisted Cable 4x10mm', '80.0'),
(1, '2020/01/16', 'Lampu Son T 250 Watt', '13.0'),
(3, '2020/01/16', 'Lampu Son T 70 Watt', '17.0'),
(5, '2020/01/16', 'Ballast SON 250 Watt', '13.0'),
(7, '2020/01/16', 'Ballast SON 70 Watt', '15.0'),
(9, '2020/01/16', 'Ignitor SN 58', '27.0'),
(10, '2020/01/16', 'Timer', '4.0'),
(11, '2020/01/16', 'Kontraktor', '3.0'),
(15, '2020/01/16', 'MCB 16 A', '2.0'),
(16, '2020/01/16', 'MCB 25 A', '3.0'),
(22, '2020/01/16', 'Fotocell 6 A', '1.0'),
(26, '2020/01/16', 'Fitting E 40', '3.0'),
(29, '2020/01/16', 'Kabel NYM 500 V 2x1.5mm', '0.7'),
(33, '2020/01/16', 'Isolasi', '2.0'),
(1, '2020/01/17', 'Lampu Son T 250 Watt', '12.0'),
(3, '2020/01/17', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/01/17', 'Ballast SON 250 Watt', '11.0'),
(7, '2020/01/17', 'Ballast SON 70 Watt', '5.0'),
(9, '2020/01/17', 'Ignitor SN 58', '16.0'),
(10, '2020/01/17', 'Timer', '2.0'),
(11, '2020/01/17', 'Kontraktor', '3.0'),
(15, '2020/01/17', 'MCB 16 A', '1.0'),
(22, '2020/01/17', 'Fotocell 6 A', '3.0'),
(24, '2020/01/17', 'Connector', '6.0'),
(26, '2020/01/17', 'Fitting E 40', '4.0'),
(29, '2020/01/17', 'Kabel NYM 500 V 2x1.5mm', '0.5'),
(33, '2020/01/17', 'Isolasi', '3.0'),
(1, '2020/01/18', 'Lampu Son T 250 Watt', '2.0'),
(3, '2020/01/18', 'Lampu Son T 70 Watt', '4.0'),
(5, '2020/01/18', 'Ballast SON 250 Watt', '2.0'),
(7, '2020/01/18', 'Ballast SON 70 Watt', '4.0'),
(9, '2020/01/18', 'Ignitor SN 58', '6.0'),
(10, '2020/01/18', 'Timer', '1.0'),
(11, '2020/01/18', 'Kontraktor', '1.0'),
(29, '2020/01/18', 'Kabel NYM 500 V 2x1.5mm', '0.3'),
(33, '2020/01/18', 'Isolasi', '1.0'),
(1, '2020/01/20', 'Lampu Son T 250 Watt', '19.0'),
(3, '2020/01/20', 'Lampu Son T 70 Watt', '7.0'),
(5, '2020/01/20', 'Ballast SON 250 Watt', '18.0'),
(7, '2020/01/20', 'Ballast SON 70 Watt', '7.0'),
(9, '2020/01/20', 'Ignitor SN 58', '22.0'),
(10, '2020/01/20', 'Timer', '3.0'),
(11, '2020/01/20', 'Kontraktor', '2.0'),
(15, '2020/01/20', 'MCB 16 A', '2.0'),
(16, '2020/01/20', 'MCB 25 A', '1.0'),
(17, '2020/01/20', 'MCB 50 A/1 Phase', '3.0'),
(22, '2020/01/20', 'Fotocell 6 A', '5.0'),
(24, '2020/01/20', 'Connector', '2.0'),
(26, '2020/01/20', 'Fitting E 40', '4.0'),
(29, '2020/01/20', 'Kabel NYM 500 V 2x1.5mm', '1.1'),
(33, '2020/01/20', 'Isolasi', '1.0'),
(1, '2020/01/21', 'Lampu Son T 250 Watt', '9.0'),
(3, '2020/01/21', 'Lampu Son T 70 Watt', '6.0'),
(5, '2020/01/21', 'Ballast SON 250 Watt', '8.0'),
(7, '2020/01/21', 'Ballast SON 70 Watt', '4.0'),
(9, '2020/01/21', 'Ignitor SN 58', '14.0'),
(10, '2020/01/21', 'Timer', '2.0'),
(11, '2020/01/21', 'Kontraktor', '2.0'),
(13, '2020/01/21', 'MCB 6 A', '26.0'),
(19, '2020/01/21', 'Armature 70 W IP 65', '2.0'),
(22, '2020/01/21', 'Fotocell 6 A', '4.0'),
(24, '2020/01/21', 'Connector', '6.0'),
(26, '2020/01/21', 'Fitting E 40', '1.0'),
(27, '2020/01/21', 'Twisted Cable 2x10mm', '250.0'),
(29, '2020/01/21', 'Kabel NYM 500 V 2x1.5mm', '1.0'),
(32, '2020/01/21', 'Tiang Besi', '2.0'),
(33, '2020/01/21', 'Isolasi', '5.0'),
(35, '2020/01/21', 'Stanless', '1.0'),
(36, '2020/01/21', 'Weid Clamp', '4.0'),
(41, '2020/01/21', 'Stoping', '8.0'),
(1, '2020/01/22', 'Lampu Son T 250 Watt', '3.0'),
(3, '2020/01/22', 'Lampu Son T 70 Watt', '14.0'),
(5, '2020/01/22', 'Ballast SON 250 Watt', '3.0'),
(7, '2020/01/22', 'Ballast SON 70 Watt', '10.0'),
(9, '2020/01/22', 'Ignitor SN 58', '12.0'),
(10, '2020/01/22', 'Timer', '3.0'),
(11, '2020/01/22', 'Kontraktor', '3.0'),
(15, '2020/01/22', 'MCB 16 A', '2.0'),
(16, '2020/01/22', 'MCB 25 A', '2.0'),
(22, '2020/01/22', 'Fotocell 6 A', '6.0'),
(24, '2020/01/22', 'Connector', '6.0'),
(26, '2020/01/22', 'Fitting E 40', '2.0'),
(29, '2020/01/22', 'Kabel NYM 500 V 2x1.5mm', '0.7'),
(33, '2020/01/22', 'Isolasi', '1.0'),
(1, '2020/01/23', 'Lampu Son T 250 Watt', '4.0'),
(3, '2020/01/23', 'Lampu Son T 70 Watt', '7.0'),
(5, '2020/01/23', 'Ballast SON 250 Watt', '7.0'),
(7, '2020/01/23', 'Ballast SON 70 Watt', '8.0'),
(9, '2020/01/23', 'Ignitor SN 58', '5.0'),
(22, '2020/01/23', 'Fotocell 6 A', '2.0'),
(24, '2020/01/23', 'Connector', '6.0'),
(26, '2020/01/23', 'Fitting E 40', '1.0'),
(33, '2020/01/23', 'Isolasi', '2.0'),
(35, '2020/01/23', 'Stanless', '1.0'),
(41, '2020/01/23', 'Stoping', '8.0'),
(1, '2020/01/24', 'Lampu Son T 250 Watt', '7.0'),
(3, '2020/01/24', 'Lampu Son T 70 Watt', '9.0'),
(5, '2020/01/24', 'Ballast SON 250 Watt', '7.0'),
(7, '2020/01/24', 'Ballast SON 70 Watt', '6.0'),
(9, '2020/01/24', 'Ignitor SN 58', '13.0'),
(10, '2020/01/24', 'Timer', '2.0'),
(11, '2020/01/24', 'Kontraktor', '2.0'),
(15, '2020/01/24', 'MCB 16 A', '2.0'),
(16, '2020/01/24', 'MCB 25 A', '2.0'),
(22, '2020/01/24', 'Fotocell 6 A', '6.0'),
(26, '2020/01/24', 'Fitting E 40', '1.0'),
(29, '2020/01/24', 'Kabel NYM 500 V 2x1.5mm', '0.7'),
(33, '2020/01/24', 'Isolasi', '1.0'),
(35, '2020/01/24', 'Stanless', '1.0'),
(41, '2020/01/24', 'Stoping', '6.0'),
(42, '2020/01/24', 'Panel', '2.0'),
(44, '2020/01/24', 'Lampu HPIT 1000 Watt', '1.0'),
(1, '2020/01/27', 'Lampu Son T 250 Watt', '4.0'),
(3, '2020/01/27', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/01/27', 'Ballast SON 250 Watt', '3.0'),
(7, '2020/01/27', 'Ballast SON 70 Watt', '5.0'),
(9, '2020/01/27', 'Ignitor SN 58', '8.0'),
(10, '2020/01/27', 'Timer', '2.0'),
(11, '2020/01/27', 'Kontraktor', '2.0'),
(13, '2020/01/27', 'MCB 6 A', '5.0'),
(16, '2020/01/27', 'MCB 25 A', '1.0'),
(22, '2020/01/27', 'Fotocell 6 A', '2.0'),
(24, '2020/01/27', 'Connector', '2.0'),
(29, '2020/01/27', 'Kabel NYM 500 V 2x1.5mm', '0.3'),
(48, '2020/01/27', 'Philips BRP210 LED 27 Watt', '10.0'),
(3, '2020/01/28', 'Lampu Son T 70 Watt', '4.0'),
(7, '2020/01/28', 'Ballast SON 70 Watt', '5.0'),
(9, '2020/01/28', 'Ignitor SN 58', '16.0'),
(10, '2020/01/28', 'Timer', '2.0'),
(11, '2020/01/28', 'Kontraktor', '2.0'),
(22, '2020/01/28', 'Fotocell 6 A', '8.0'),
(24, '2020/01/28', 'Connector', '2.0'),
(26, '2020/01/28', 'Fitting E 40', '1.0'),
(29, '2020/01/28', 'Kabel NYM 500 V 2x1.5mm', '0.3'),
(33, '2020/01/28', 'Isolasi', '2.0'),
(1, '2020/01/29', 'Lampu Son T 250 Watt', '4.0'),
(3, '2020/01/29', 'Lampu Son T 70 Watt', '3.0'),
(5, '2020/01/29', 'Ballast SON 250 Watt', '4.0'),
(7, '2020/01/29', 'Ballast SON 70 Watt', '3.0'),
(9, '2020/01/29', 'Ignitor SN 58', '6.0'),
(11, '2020/01/29', 'Kontraktor', '4.0'),
(16, '2020/01/29', 'MCB 25 A', '1.0'),
(17, '2020/01/29', 'MCB 50 A/1 Phase', '2.0'),
(22, '2020/01/29', 'Fotocell 6 A', '2.0'),
(29, '2020/01/29', 'Kabel NYM 500 V 2x1.5mm', '0.7'),
(33, '2020/01/29', 'Isolasi', '1.0'),
(36, '2020/01/29', 'Weid Clamp', '2.0'),
(41, '2020/01/29', 'Stoping', '20.0'),
(48, '2020/01/29', 'Philips BRP210 LED 27 Watt', '2.0'),
(1, '2020/01/30', 'Lampu Son T 250 Watt', '6.0'),
(3, '2020/01/30', 'Lampu Son T 70 Watt', '3.0'),
(5, '2020/01/30', 'Ballast SON 250 Watt', '11.0'),
(7, '2020/01/30', 'Ballast SON 70 Watt', '3.0'),
(9, '2020/01/30', 'Ignitor SN 58', '13.0'),
(10, '2020/01/30', 'Timer', '2.0'),
(13, '2020/01/30', 'MCB 6 A', '6.0'),
(17, '2020/01/30', 'MCB 50 A/1 Phase', '2.0'),
(26, '2020/01/30', 'Fitting E 40', '3.0'),
(1, '2020/01/31', 'Lampu Son T 250 Watt', '5.0'),
(3, '2020/01/31', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/01/31', 'Ballast SON 250 Watt', '6.0'),
(7, '2020/01/31', 'Ballast SON 70 Watt', '4.0'),
(9, '2020/01/31', 'Ignitor SN 58', '9.0'),
(17, '2020/01/31', 'MCB 50 A/1 Phase', '2.0'),
(22, '2020/01/31', 'Fotocell 6 A', '2.0'),
(23, '2020/01/31', 'Fotocell 10 A', '1.0'),
(24, '2020/01/31', 'Connector', '4.0'),
(26, '2020/01/31', 'Fitting E 40', '5.0'),
(29, '2020/01/31', 'Kabel NYM 500 V 2x1.5mm', '0.6'),
(41, '2020/01/31', 'Stoping', '5.0'),
(13, '2020/01/22', 'MCB 6 A', '4.0'),
(26, '2020/01/06', 'Fitting E 40', '5.0'),
(1, '2020/01/02', 'Lampu Son T 250 Watt', '5.0'),
(3, '2020/01/02', 'Lampu Son T 70 Watt', '3.0'),
(5, '2020/01/02', 'Ballast SON 250 Watt', '10.0'),
(7, '2020/01/02', 'Ballast SON 70 Watt', '7.0'),
(9, '2020/01/02', 'Ignitor SN 58', '10.0'),
(10, '2020/01/02', 'Timer', '2.0'),
(11, '2020/01/02', 'Kontraktor', '2.0'),
(15, '2020/01/02', 'MCB 16 A', '2.0'),
(22, '2020/01/02', 'Fotocell 6 A', '7.0'),
(26, '2020/01/02', 'Fitting E 40', '5.0'),
(27, '2020/01/02', 'Twisted Cable 2x10mm', '250.0'),
(36, '2020/01/02', 'Weid Clamp', '2.0'),
(1, '2020/01/03', 'Lampu Son T 250 Watt', '11.0'),
(3, '2020/01/03', 'Lampu Son T 70 Watt', '4.0'),
(7, '2020/01/03', 'Ballast SON 70 Watt', '4.0'),
(5, '2020/01/03', 'Ballast SON 250 Watt', '11.0'),
(9, '2020/01/03', 'Ignitor SN 58', '21.0'),
(10, '2020/01/03', 'Timer', '2.0'),
(11, '2020/01/03', 'Kontraktor', '1.0'),
(15, '2020/01/03', 'MCB 16 A', '2.0'),
(22, '2020/01/03', 'Fotocell 6 A', '8.0'),
(33, '2020/01/03', 'Isolasi', '1.0'),
(36, '2020/01/03', 'Weid Clamp', '3.0'),
(41, '2020/01/03', 'Stoping', '9.0'),
(66, '2020/01/03', 'Stang 2 x 1.5\"', '3.0'),
(1, '2020/01/04', 'Lampu Son T 250 Watt', '4.0'),
(3, '2020/01/04', 'Lampu Son T 70 Watt', '4.0'),
(5, '2020/01/04', 'Ballast SON 250 Watt', '4.0'),
(7, '2020/01/04', 'Ballast SON 70 Watt', '4.0'),
(9, '2020/01/04', 'Ignitor SN 58', '7.0'),
(10, '2020/01/04', 'Timer', '2.0'),
(15, '2020/01/04', 'MCB 16 A', '2.0'),
(22, '2020/01/04', 'Fotocell 6 A', '1.0'),
(29, '2020/01/04', 'Kabel NYM 500 V 2x1.5mm', '0.2'),
(33, '2020/01/04', 'Isolasi', '1.0'),
(26, '2020/01/03', 'Fitting E 40', '5.0'),
(48, '2020/01/20', 'Philips BRP210 LED 27 Watt', '1.0'),
(25, '2020/01/16', 'Fitting E 27', '4.0'),
(25, '2020/01/20', 'Fitting E 27', '6.0'),
(25, '2020/01/21', 'Fitting E 27', '3.0'),
(25, '2020/01/22', 'Fitting E 27', '6.0'),
(25, '2020/01/23', 'Fitting E 27', '1.0'),
(25, '2020/01/24', 'Fitting E 27', '3.0'),
(25, '2020/01/27', 'Fitting E 27', '5.0'),
(25, '2020/01/28', 'Fitting E 27', '5.0'),
(25, '2020/01/30', 'Fitting E 27', '6.0'),
(25, '2020/01/31', 'Fitting E 27', '1.0'),
(1, '2020/02/01', 'Lampu Son T 250 Watt', '6.0'),
(3, '2020/02/01', 'Lampu Son T 70 Watt', '6.0'),
(5, '2020/02/01', 'Ballast SON 250 Watt', '5.0'),
(7, '2020/02/01', 'Ballast SON 70 Watt', '6.0'),
(9, '2020/02/01', 'Ignitor SN 58', '6.0'),
(10, '2020/02/01', 'Timer', '1.0'),
(11, '2020/02/01', 'Kontraktor', '1.0'),
(22, '2020/02/01', 'Fotocell 6 A', '6.0'),
(29, '2020/02/01', 'Kabel NYM 500 V 2x1.5mm', '0.3'),
(33, '2020/02/01', 'Isolasi', '1.0'),
(1, '2020/02/03', 'Lampu Son T 250 Watt', '8.0'),
(3, '2020/02/03', 'Lampu Son T 70 Watt', '4.0'),
(5, '2020/02/03', 'Ballast SON 250 Watt', '8.0'),
(7, '2020/02/03', 'Ballast SON 70 Watt', '4.0'),
(9, '2020/02/03', 'Ignitor SN 58', '14.0'),
(10, '2020/02/03', 'Timer', '1.0'),
(11, '2020/02/03', 'Kontraktor', '1.0'),
(13, '2020/02/03', 'MCB 6 A', '6.0'),
(24, '2020/02/03', 'Connector', '2.0'),
(26, '2020/02/03', 'Fitting E 40', '2.0'),
(29, '2020/02/03', 'Kabel NYM 500 V 2x1.5mm', '1.3'),
(33, '2020/02/03', 'Isolasi', '2.0'),
(1, '2020/02/04', 'Lampu Son T 250 Watt', '9.0'),
(3, '2020/02/04', 'Lampu Son T 70 Watt', '5.0'),
(5, '2020/02/04', 'Ballast SON 250 Watt', '7.0'),
(7, '2020/02/04', 'Ballast SON 70 Watt', '5.0'),
(9, '2020/02/04', 'Ignitor SN 58', '18.0'),
(10, '2020/02/04', 'Timer', '3.0'),
(11, '2020/02/04', 'Kontraktor', '2.0'),
(22, '2020/02/04', 'Fotocell 6 A', '8.0'),
(25, '2020/02/04', 'Fitting E 27', '4.0'),
(26, '2020/02/04', 'Fitting E 40', '2.0'),
(29, '2020/02/04', 'Kabel NYM 500 V 2x1.5mm', '0.7'),
(33, '2020/02/04', 'Isolasi', '1.0'),
(3, '2020/02/05', 'Lampu Son T 70 Watt', '4.0'),
(7, '2020/02/05', 'Ballast SON 70 Watt', '3.0'),
(9, '2020/02/05', 'Ignitor SN 58', '3.0'),
(10, '2020/02/05', 'Timer', '1.0'),
(11, '2020/02/05', 'Kontraktor', '2.0'),
(15, '2020/02/05', 'MCB 16 A', '1.0'),
(16, '2020/02/05', 'MCB 25 A', '2.0'),
(22, '2020/02/05', 'Fotocell 6 A', '7.0'),
(25, '2020/02/05', 'Fitting E 27', '2.0'),
(26, '2020/02/05', 'Fitting E 40', '1.0'),
(29, '2020/02/05', 'Kabel NYM 500 V 2x1.5mm', '0.4'),
(35, '2020/02/05', 'Stanless', '1.0'),
(48, '2020/02/05', 'Philips BRP210 LED 27 Watt', '3.0'),
(66, '2020/02/05', 'Stang 2 x 1.5\"', '2.0'),
(1, '2020/02/06', 'Lampu Son T 250 Watt', '5.0'),
(3, '2020/02/06', 'Lampu Son T 70 Watt', '2.0'),
(5, '2020/02/06', 'Ballast SON 250 Watt', '3.0'),
(7, '2020/02/06', 'Ballast SON 70 Watt', '2.0'),
(9, '2020/02/06', 'Ignitor SN 58', '9.0'),
(22, '2020/02/06', 'Fotocell 6 A', '4.0'),
(24, '2020/02/06', 'Connector', '2.0'),
(26, '2020/02/06', 'Fitting E 40', '3.0'),
(29, '2020/02/06', 'Kabel NYM 500 V 2x1.5mm', '0.7'),
(33, '2020/02/06', 'Isolasi', '1.0'),
(1, '2020/02/07', 'Lampu Son T 250 Watt', '1.0'),
(3, '2020/02/07', 'Lampu Son T 70 Watt', '9.0'),
(5, '2020/02/07', 'Ballast SON 250 Watt', '1.0'),
(7, '2020/02/07', 'Ballast SON 70 Watt', '9.0'),
(9, '2020/02/07', 'Ignitor SN 58', '9.0'),
(11, '2020/02/07', 'Kontraktor', '1.0'),
(15, '2020/02/07', 'MCB 16 A', '2.0'),
(16, '2020/02/07', 'MCB 25 A', '1.0'),
(22, '2020/02/07', 'Fotocell 6 A', '2.0'),
(24, '2020/02/07', 'Connector', '4.0'),
(25, '2020/02/07', 'Fitting E 27', '3.0'),
(26, '2020/02/07', 'Fitting E 40', '2.0'),
(29, '2020/02/07', 'Kabel NYM 500 V 2x1.5mm', '0.6'),
(33, '2020/02/07', 'Isolasi', '2.0'),
(48, '2020/02/07', 'Philips BRP210 LED 27 Watt', '2.0'),
(1, '2020/02/08', 'Lampu Son T 250 Watt', '4.0'),
(3, '2020/02/08', 'Lampu Son T 70 Watt', '3.0'),
(5, '2020/02/08', 'Ballast SON 250 Watt', '4.0'),
(7, '2020/02/08', 'Ballast SON 70 Watt', '2.0'),
(9, '2020/02/08', 'Ignitor SN 58', '4.0'),
(10, '2020/02/08', 'Timer', '1.0'),
(11, '2020/02/08', 'Kontraktor', '1.0'),
(24, '2020/02/08', 'Connector', '4.0'),
(29, '2020/02/08', 'Kabel NYM 500 V 2x1.5mm', '0.3'),
(1, '2020/02/10', 'Lampu Son T 250 Watt', '12.0'),
(3, '2020/02/10', 'Lampu Son T 70 Watt', '7.0'),
(5, '2020/02/10', 'Ballast SON 250 Watt', '10.0'),
(7, '2020/02/10', 'Ballast SON 70 Watt', '7.0'),
(9, '2020/02/10', 'Ignitor SN 58', '18.0'),
(10, '2020/02/10', 'Timer', '1.0'),
(11, '2020/02/10', 'Kontraktor', '2.0'),
(25, '2020/02/10', 'Fitting E 27', '3.0'),
(29, '2020/02/10', 'Kabel NYM 500 V 2x1.5mm', '1.2'),
(33, '2020/02/10', 'Isolasi', '2.0'),
(1, '2020/02/11', 'Lampu Son T 250 Watt', '11.0'),
(3, '2020/02/11', 'Lampu Son T 70 Watt', '11.0'),
(5, '2020/02/11', 'Ballast SON 250 Watt', '9.0'),
(7, '2020/02/11', 'Ballast SON 70 Watt', '13.0'),
(9, '2020/02/11', 'Ignitor SN 58', '20.0'),
(11, '2020/02/11', 'Kontraktor', '1.0'),
(15, '2020/02/11', 'MCB 16 A', '2.0'),
(16, '2020/02/11', 'MCB 25 A', '3.0'),
(22, '2020/02/11', 'Fotocell 6 A', '15.0'),
(24, '2020/02/11', 'Connector', '8.0'),
(25, '2020/02/11', 'Fitting E 27', '9.0'),
(26, '2020/02/11', 'Fitting E 40', '7.0'),
(29, '2020/02/11', 'Kabel NYM 500 V 2x1.5mm', '2.4'),
(33, '2020/02/11', 'Isolasi', '2.0'),
(41, '2020/02/11', 'Stoping', '20.0'),
(66, '2020/02/11', 'Stang 2 x 1.5\"', '6.0'),
(1, '2020/02/12', 'Lampu Son T 250 Watt', '7.0'),
(3, '2020/02/12', 'Lampu Son T 70 Watt', '12.0'),
(5, '2020/02/12', 'Ballast SON 250 Watt', '8.0'),
(7, '2020/02/12', 'Ballast SON 70 Watt', '8.0'),
(9, '2020/02/12', 'Ignitor SN 58', '19.0'),
(10, '2020/02/12', 'Timer', '2.0'),
(11, '2020/02/12', 'Kontraktor', '1.0'),
(22, '2020/02/12', 'Fotocell 6 A', '4.0'),
(24, '2020/02/12', 'Connector', '6.0'),
(25, '2020/02/12', 'Fitting E 27', '1.0'),
(26, '2020/02/12', 'Fitting E 40', '2.0'),
(29, '2020/02/12', 'Kabel NYM 500 V 2x1.5mm', '1.0'),
(33, '2020/02/12', 'Isolasi', '1.0'),
(41, '2020/02/12', 'Stoping', '6.0'),
(66, '2020/02/12', 'Stang 2 x 1.5\"', '1.0'),
(1, '2020/02/13', 'Lampu Son T 250 Watt', '6.0'),
(3, '2020/02/13', 'Lampu Son T 70 Watt', '15.0'),
(5, '2020/02/13', 'Ballast SON 250 Watt', '5.0'),
(7, '2020/02/13', 'Ballast SON 70 Watt', '14.0'),
(9, '2020/02/13', 'Ignitor SN 58', '21.0'),
(10, '2020/02/13', 'Timer', '3.0'),
(11, '2020/02/13', 'Kontraktor', '3.0'),
(15, '2020/02/13', 'MCB 16 A', '4.0'),
(16, '2020/02/13', 'MCB 25 A', '4.0'),
(22, '2020/02/13', 'Fotocell 6 A', '11.0'),
(24, '2020/02/13', 'Connector', '10.0'),
(25, '2020/02/13', 'Fitting E 27', '7.0'),
(26, '2020/02/13', 'Fitting E 40', '5.0'),
(29, '2020/02/13', 'Kabel NYM 500 V 2x1.5mm', '1.1'),
(33, '2020/02/13', 'Isolasi', '2.0'),
(35, '2020/02/13', 'Stanless', '1.0'),
(41, '2020/02/13', 'Stoping', '10.0'),
(1, '2020/02/14', 'Lampu Son T 250 Watt', '14.0'),
(3, '2020/02/14', 'Lampu Son T 70 Watt', '14.0'),
(5, '2020/02/14', 'Ballast SON 250 Watt', '9.0'),
(7, '2020/02/14', 'Ballast SON 70 Watt', '6.0'),
(9, '2020/02/14', 'Ignitor SN 58', '24.0'),
(10, '2020/02/14', 'Timer', '3.0'),
(11, '2020/02/14', 'Kontraktor', '3.0'),
(15, '2020/02/14', 'MCB 16 A', '2.0'),
(16, '2020/02/14', 'MCB 25 A', '4.0'),
(22, '2020/02/14', 'Fotocell 6 A', '6.0'),
(24, '2020/02/14', 'Connector', '14.0'),
(25, '2020/02/14', 'Fitting E 27', '3.0'),
(26, '2020/02/14', 'Fitting E 40', '2.0'),
(29, '2020/02/14', 'Kabel NYM 500 V 2x1.5mm', '1.0'),
(33, '2020/02/14', 'Isolasi', '2.0'),
(1, '2020/02/15', 'Lampu Son T 250 Watt', '11.0'),
(5, '2020/02/15', 'Ballast SON 250 Watt', '10.0'),
(9, '2020/02/15', 'Ignitor SN 58', '11.0'),
(10, '2020/02/15', 'Timer', '1.0'),
(11, '2020/02/15', 'Kontraktor', '1.0'),
(22, '2020/02/15', 'Fotocell 6 A', '2.0'),
(26, '2020/02/15', 'Fitting E 40', '1.0'),
(29, '2020/02/15', 'Kabel NYM 500 V 2x1.5mm', '0.1');

--
-- Triggers `barang_keluar`
--
DELIMITER $$
CREATE TRIGGER `after_delete_keluar` AFTER DELETE ON `barang_keluar` FOR EACH ROW UPDATE stok_barang SET jumlah = jumlah + old.jumlah WHERE nama_barang = old.nama_barang
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_keluar` AFTER INSERT ON `barang_keluar` FOR EACH ROW BEGIN
	UPDATE stok_barang set jumlah= jumlah-NEW.jumlah
    WHERE nama_barang = NEW.nama_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `no` int(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `barang_masuk`
--
DELIMITER $$
CREATE TRIGGER `after_delete_masuk` AFTER DELETE ON `barang_masuk` FOR EACH ROW UPDATE stok_barang SET jumlah = jumlah - old.jumlah WHERE nama_barang = old.nama_barang
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_masuk` AFTER INSERT ON `barang_masuk` FOR EACH ROW BEGIN
	UPDATE stok_barang set jumlah= jumlah+NEW.jumlah
    WHERE nama_barang = NEW.nama_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `hasil_pakai`
--

CREATE TABLE `hasil_pakai` (
  `no` int(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `barang_masuk` varchar(100) NOT NULL,
  `jumlah_pakai` varchar(100) NOT NULL,
  `sisa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hasil_pakai`
--

INSERT INTO `hasil_pakai` (`no`, `tanggal`, `nama_barang`, `barang_masuk`, `jumlah_pakai`, `sisa`) VALUES
(1, '2020/02/01', 'Lampu Son T 250 Watt', '0', '94', '1467'),
(3, '2020/02/01', 'Lampu Son T 70 Watt', '0', '92', '1831'),
(5, '2020/02/01', 'Ballast SON 250 Watt', '0', '79', '1463'),
(7, '2020/02/01', 'Ballast SON 70 Watt', '0', '79', '1935'),
(9, '2020/02/01', 'Ignitor SN 58', '0', '176', '4941'),
(10, '2020/02/01', 'Timer', '0', '17', '84'),
(11, '2020/02/01', 'Kontraktor', '0', '19', '57'),
(13, '2020/02/03', 'MCB 6 A', '0', '6', '129'),
(15, '2020/02/05', 'MCB 16 A', '0', '11', '284'),
(16, '2020/02/05', 'MCB 25 A', '0', '14', '346'),
(22, '2020/02/01', 'Fotocell 6 A', '0', '65', '1672'),
(24, '2020/02/03', 'Connector', '0', '50', '1680'),
(25, '2020/02/04', 'Fitting E 27', '0', '32', '108'),
(26, '2020/02/03', 'Fitting E 40', '0', '27', '195'),
(29, '2020/02/01', 'Kabel NYM 500 V 2x1.5mm', '0', '11.1', '98.60000000000001'),
(33, '2020/02/01', 'Isolasi', '0', '16', '952'),
(35, '2020/02/05', 'Stanless', '0', '2', '139'),
(41, '2020/02/11', 'Stoping', '0', '36', '342'),
(48, '2020/02/05', 'Philips BRP210 LED 27 Watt', '0', '5', '6'),
(66, '2020/02/05', 'Stang 2 x 1.5\"', '0', '9', '87');

-- --------------------------------------------------------

--
-- Table structure for table `laporan_sementara`
--

CREATE TABLE `laporan_sementara` (
  `no` int(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `stok_bulan_lalu` varchar(100) NOT NULL,
  `barang_masuk` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `jumlah_pakai` varchar(100) NOT NULL,
  `sisa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laporan_sementara`
--

INSERT INTO `laporan_sementara` (`no`, `nama_barang`, `stok_bulan_lalu`, `barang_masuk`, `tanggal`, `jumlah_pakai`, `sisa`) VALUES
(1, 'Lampu Son T 250 Watt', '1561', '0', 'Februari 2020', '94', '1467'),
(2, 'Lampu Son T 150 Watt', '0', '0', 'Februari 2020', '0', '0'),
(3, 'Lampu Son T 70 Watt', '1923', '0', 'Februari 2020', '92', '1831'),
(4, 'Lampu HE 45 Watt', '0', '0', 'Februari 2020', '0', '0'),
(5, 'Ballast SON 250 Watt', '1542', '0', 'Februari 2020', '79', '1463'),
(6, 'Ballast SON 150 Watt', '3', '0', 'Februari 2020', '0', '3'),
(7, 'Ballast SON 70 Watt', '2014', '0', 'Februari 2020', '79', '1935'),
(8, 'Ignitor SI', '363', '0', 'Februari 2020', '0', '363'),
(9, 'Ignitor SN 58', '5117', '0', 'Februari 2020', '176', '4941'),
(10, 'Timer', '101', '0', 'Februari 2020', '17', '84'),
(11, 'Kontraktor', '76', '0', 'Februari 2020', '19', '57'),
(12, 'NFB 50 A', '0', '0', 'Februari 2020', '0', '0'),
(13, 'MCB 6 A', '135', '0', 'Februari 2020', '6', '129'),
(14, 'MCB 10 A', '415', '0', 'Februari 2020', '0', '415'),
(15, 'MCB 16 A', '295', '0', 'Februari 2020', '11', '284'),
(16, 'MCB 25 A', '360', '0', 'Februari 2020', '14', '346'),
(17, 'MCB 50 A/1 Phase', '327', '0', 'Februari 2020', '0', '327'),
(18, 'Armature 250 W IP 65', '43', '0', 'Februari 2020', '0', '43'),
(19, 'Armature 70 W IP 65', '32', '0', 'Februari 2020', '0', '32'),
(20, 'Armature Jalan Lingkungan', '1', '0', 'Februari 2020', '0', '1'),
(21, 'Armature LP Sorot 250 Watt', '18', '0', 'Februari 2020', '0', '18'),
(22, 'Fotocell 6 A', '1737', '0', 'Februari 2020', '65', '1672'),
(23, 'Fotocell 10 A', '241', '0', 'Februari 2020', '0', '241'),
(24, 'Connector', '1730', '0', 'Februari 2020', '50', '1680'),
(25, 'Fitting E 27', '140', '0', 'Februari 2020', '32', '108'),
(26, 'Fitting E 40', '222', '0', 'Februari 2020', '27', '195'),
(27, 'Twisted Cable 2x10mm', '0', '0', 'Februari 2020', '0', '0'),
(28, 'Twisted Cable 4x10mm', '0', '0', 'Februari 2020', '0', '0'),
(29, 'Kabel NYM 500 V 2x1.5mm', '109.7', '0', 'Februari 2020', '11.1', '98.60000000000001'),
(30, 'Stang 3 Meter', '17', '0', 'Februari 2020', '0', '17'),
(31, 'Stang 6 Meter', '19', '0', 'Februari 2020', '0', '19'),
(32, 'Tiang Besi', '13', '0', 'Februari 2020', '0', '13'),
(33, 'Isolasi', '968', '0', 'Februari 2020', '16', '952'),
(34, 'Braket', '150', '0', 'Februari 2020', '0', '150'),
(35, 'Stanless', '141', '0', 'Februari 2020', '2', '139'),
(36, 'Weid Clamp', '1535', '0', 'Februari 2020', '0', '1535'),
(37, 'Lampu Hias', '98', '0', 'Februari 2020', '0', '98'),
(38, 'Angkur', '85', '0', 'Februari 2020', '0', '85'),
(39, 'Rangka Pondasi', '18', '0', 'Februari 2020', '0', '18'),
(40, 'Sling', '1483', '0', 'Februari 2020', '0', '1483'),
(41, 'Stoping', '378', '0', 'Februari 2020', '36', '342'),
(42, 'Panel', '21', '0', 'Februari 2020', '0', '21'),
(43, 'Gembok Panel', '0', '0', 'Februari 2020', '0', '0'),
(44, 'Lampu HPIT 1000 Watt', '23', '0', 'Februari 2020', '0', '23'),
(45, 'Ballast 1000 Watt', '25', '0', 'Februari 2020', '0', '25'),
(46, 'Armature Lampu HPIT 1000 Watt Sodium Lengkap', '3', '0', 'Februari 2020', '0', '3'),
(47, 'Stang 3 Meter 1.5 inch', '0', '0', 'Februari 2020', '0', '0'),
(48, 'Philips BRP210 LED 27 Watt', '11', '0', 'Februari 2020', '5', '6'),
(49, 'Philips HPIT 400 Watt', '35', '0', 'Februari 2020', '0', '35'),
(50, 'Philips HPIT 250 Watt', '42', '0', 'Februari 2020', '0', '42'),
(51, 'Ballast MH 400', '36', '0', 'Februari 2020', '0', '36'),
(52, 'Ballast MH 250', '52', '0', 'Februari 2020', '0', '52'),
(53, 'Twisted Cable 2x16mm', '0', '0', 'Februari 2020', '0', '0'),
(54, 'Twisted Cable 4x16mm', '2080', '0', 'Februari 2020', '0', '2080'),
(55, 'NH-Fuse', '20', '0', 'Februari 2020', '0', '20'),
(56, 'Armature Lengkap LED DC 40 Watt', '4', '0', 'Februari 2020', '0', '4'),
(57, 'Batterai VLRA 12V 65 A', '6', '0', 'Februari 2020', '0', '6'),
(58, 'Batterai Control Regulator 20 A', '0', '0', 'Februari 2020', '0', '0'),
(59, 'Armature LED 75 Watt Ellipz', '12', '0', 'Februari 2020', '0', '12'),
(60, 'Consentrator', '3', '0', 'Februari 2020', '0', '3'),
(61, 'Controller Smartsystem', '16', '0', 'Februari 2020', '0', '16'),
(62, 'Armature Sorot 400 Watt', '10', '0', 'Februari 2020', '0', '10'),
(63, 'LED Celling Underpass 200 Watt', '2', '0', 'Februari 2020', '0', '2'),
(64, 'Kontraktor 25 A', '0', '0', 'Februari 2020', '0', '0'),
(65, 'Lampu LED 120 Watt', '10', '0', 'Februari 2020', '0', '10'),
(66, 'Stang 2 x 1.5\"', '96', '0', 'Februari 2020', '9', '87');

-- --------------------------------------------------------

--
-- Table structure for table `pemakaian_barang`
--

CREATE TABLE `pemakaian_barang` (
  `no` int(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `stok_bulan_lalu` varchar(100) NOT NULL,
  `barang_masuk` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `jumlah_pakai` varchar(100) NOT NULL,
  `sisa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemakaian_barang`
--

INSERT INTO `pemakaian_barang` (`no`, `nama_barang`, `stok_bulan_lalu`, `barang_masuk`, `tanggal`, `jumlah_pakai`, `sisa`) VALUES
(1, 'Lampu Son T 250 Watt', '1741', '0', 'Januari 2020', '180', '1561'),
(2, 'Lampu Son T 150 Watt', '0', '0', 'Januari 2020', '0', '0'),
(3, 'Lampu Son T 70 Watt', '2067', '0', 'Januari 2020', '144', '1923'),
(4, 'Lampu HE 45 Watt', '0', '0', 'Januari 2020', '0', '0'),
(5, 'Ballast SON 250 Watt', '1736', '0', 'Januari 2020', '194', '1542'),
(6, 'Ballast SON 150 Watt', '3', '0', 'Januari 2020', '0', '3'),
(7, 'Ballast SON 70 Watt', '2174', '0', 'Januari 2020', '160', '2014'),
(8, 'Ignitor SI', '363', '0', 'Januari 2020', '0', '363'),
(9, 'Ignitor SN 58', '5445', '0', 'Januari 2020', '328', '5117'),
(10, 'Timer', '132', '0', 'Januari 2020', '31', '101'),
(11, 'Kontraktor', '103', '0', 'Januari 2020', '27', '76'),
(12, 'NFB 50 A', '0', '0', 'Januari 2020', '0', '0'),
(13, 'MCB 6 A', '176', '0', 'Januari 2020', '41', '135'),
(14, 'MCB 10 A', '415', '0', 'Januari 2020', '0', '415'),
(15, 'MCB 16 A', '324', '0', 'Januari 2020', '29', '295'),
(16, 'MCB 25 A', '370', '0', 'Januari 2020', '10', '360'),
(17, 'MCB 50 A/1 Phase', '341', '0', 'Januari 2020', '14', '327'),
(18, 'Armature 250 W IP 65', '43', '0', 'Januari 2020', '0', '43'),
(19, 'Armature 70 W IP 65', '34', '0', 'Januari 2020', '2', '32'),
(20, 'Armature Jalan Lingkungan', '1', '0', 'Januari 2020', '0', '1'),
(21, 'Armature LP Sorot 250 Watt', '19', '0', 'Januari 2020', '0', '18'),
(22, 'Fotocell 6 A', '1817', '0', 'Januari 2020', '80', '1737'),
(23, 'Fotocell 10 A', '242', '0', 'Januari 2020', '1', '241'),
(24, 'Connector', '1782', '0', 'Januari 2020', '52', '1730'),
(25, 'Fitting E 27', '180', '0', 'Januari 2020', '40', '140'),
(26, 'Fitting E 40', '272', '0', 'Januari 2020', '50', '222'),
(27, 'Twisted Cable 2x10mm', '1000', '0', 'Januari 2020', '1000', '0'),
(28, 'Twisted Cable 4x10mm', '80', '0', 'Januari 2020', '80', '0'),
(29, 'Kabel NYM 500 V 2x1.5mm', '120.09', '0', 'Januari 2020', '10.4', '109.7'),
(30, 'Stang 3 Meter', '17', '0', 'Januari 2020', '0', '17'),
(31, 'Stang 6 Meter', '19', '0', 'Januari 2020', '0', '19'),
(32, 'Tiang Besi', '15', '0', 'Januari 2020', '2', '13'),
(33, 'Isolasi', '995', '0', 'Januari 2020', '27', '968'),
(34, 'Braket', '150', '0', 'Januari 2020', '0', '150'),
(35, 'Stanless', '145', '0', 'Januari 2020', '4', '141'),
(36, 'Weid Clamp', '1571', '0', 'Januari 2020', '36', '1535'),
(37, 'Lampu Hias', '98', '0', 'Januari 2020', '0', '98'),
(38, 'Angkur', '85', '0', 'Januari 2020', '0', '85'),
(39, 'Rangka Pondasi', '18', '0', 'Januari 2020', '0', '18'),
(40, 'Sling', '1483', '0', 'Januari 2020', '0', '1483'),
(41, 'Stoping', '440', '0', 'Januari 2020', '62', '378'),
(42, 'Panel', '23', '0', 'Januari 2020', '2', '21'),
(43, 'Gembok Panel', '0', '0', 'Januari 2020', '0', '0'),
(44, 'Lampu HPIT 1000 Watt', '24', '0', 'Januari 2020', '1', '23'),
(45, 'Ballast 1000 Watt', '25', '0', 'Januari 2020', '0', '25'),
(46, 'Armature Lampu HPIT 1000 Watt Sodium Lengkap', '3', '0', 'Januari 2020', '0', '3'),
(47, 'Stang 3 Meter 1.5 inch', '0', '0', 'Januari 2020', '0', '0'),
(48, 'Philips BRP210 LED 27 Watt', '24', '0', 'Januari 2020', '13', '11'),
(49, 'Philips HPIT 400 Watt', '35', '0', 'Januari 2020', '0', '35'),
(50, 'Philips HPIT 250 Watt', '42', '0', 'Januari 2020', '0', '42'),
(51, 'Ballast MH 400', '36', '0', 'Januari 2020', '0', '36'),
(52, 'Ballast MH 250', '52', '0', 'Januari 2020', '0', '52'),
(53, 'Twisted Cable 2x16mm', '0', '0', 'Januari 2020', '0', '0'),
(54, 'Twisted Cable 4x16mm', '2080', '0', 'Januari 2020', '0', '2080'),
(55, 'NH-Fuse', '20', '0', 'Januari 2020', '0', '20'),
(56, 'Armature Lengkap LED DC 40 Watt', '4', '0', 'Januari 2020', '0', '4'),
(57, 'Batterai VLRA 12V 65 A', '6', '0', 'Januari 2020', '0', '6'),
(58, 'Batterai Control Regulator 20 A', '0', '0', 'Januari 2020', '0', '0'),
(59, 'Armature LED 75 Watt Ellipz', '12', '0', 'Januari 2020', '0', '12'),
(60, 'Consentrator', '3', '0', 'Januari 2020', '0', '3'),
(61, 'Controller Smartsystem', '16', '0', 'Januari 2020', '0', '16'),
(62, 'Armature Sorot 400 Watt', '10', '0', 'Januari 2020', '0', '10'),
(63, 'LED Celling Underpass 200 Watt', '2', '0', 'Januari 2020', '0', '2'),
(64, 'Kontraktor 25 A', '0', '0', 'Januari 2020', '0', '0'),
(65, 'Lampu LED 120 Watt', '10', '0', 'Januari 2020', '0', '10'),
(66, 'Stang 2 x 1.5\"', '100', '0', 'Januari 2020', '4', '96');

-- --------------------------------------------------------

--
-- Table structure for table `stok_barang`
--

CREATE TABLE `stok_barang` (
  `no` int(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok_barang`
--

INSERT INTO `stok_barang` (`no`, `nama_barang`, `jumlah`) VALUES
(1, 'Lampu Son T 250 Watt', '1467'),
(2, 'Lampu Son T 150 Watt', '0'),
(3, 'Lampu Son T 70 Watt', '1831'),
(4, 'Lampu HE 45 Watt', '0'),
(5, 'Ballast SON 250 Watt', '1463'),
(6, 'Ballast SON 150 Watt', '3'),
(7, 'Ballast SON 70 Watt', '1935'),
(8, 'Ignitor SI', '363'),
(9, 'Ignitor SN 58', '4941'),
(10, 'Timer', '84'),
(11, 'Kontraktor', '57'),
(12, 'NFB 50 A', '0'),
(13, 'MCB 6 A', '129'),
(14, 'MCB 10 A', '415'),
(15, 'MCB 16 A', '284'),
(16, 'MCB 25 A', '346'),
(17, 'MCB 50 A/1 Phase', '327'),
(18, 'Armature 250 W IP 65', '43'),
(19, 'Armature 70 W IP 65', '32'),
(20, 'Armature Jalan Lingkungan', '1'),
(21, 'Armature LP Sorot 250 Watt', '18'),
(22, 'Fotocell 6 A', '1672'),
(23, 'Fotocell 10 A', '241'),
(24, 'Connector', '1680'),
(25, 'Fitting E 27', '108'),
(26, 'Fitting E 40', '195'),
(27, 'Twisted Cable 2x10mm', '0'),
(28, 'Twisted Cable 4x10mm', '0'),
(29, 'Kabel NYM 500 V 2x1.5mm', '98.60000000000001'),
(30, 'Stang 3 Meter', '17'),
(31, 'Stang 6 Meter', '19'),
(32, 'Tiang Besi', '13'),
(33, 'Isolasi', '952'),
(34, 'Braket', '150'),
(35, 'Stanless', '139'),
(36, 'Weid Clamp', '1535'),
(37, 'Lampu Hias', '98'),
(38, 'Angkur', '85'),
(39, 'Rangka Pondasi', '18'),
(40, 'Sling', '1483'),
(41, 'Stoping', '342'),
(42, 'Panel', '21'),
(43, 'Gembok Panel', '0'),
(44, 'Lampu HPIT 1000 Watt', '23'),
(45, 'Ballast 1000 Watt', '25'),
(46, 'Armature Lampu HPIT 1000 Watt Sodium Lengkap', '3'),
(47, 'Stang 3 Meter 1.5 inch', '0'),
(48, 'Philips BRP210 LED 27 Watt', '6'),
(49, 'Philips HPIT 400 Watt', '35'),
(50, 'Philips HPIT 250 Watt', '42'),
(51, 'Ballast MH 400', '36'),
(52, 'Ballast MH 250', '52'),
(53, 'Twisted Cable 2x16mm', '0'),
(54, 'Twisted Cable 4x16mm', '2080'),
(55, 'NH-Fuse', '20'),
(56, 'Armature Lengkap LED DC 40 Watt', '4'),
(57, 'Batterai VLRA 12V 65 A', '6'),
(58, 'Batterai Control Regulator 20 A', '0'),
(59, 'Armature LED 75 Watt Ellipz', '12'),
(60, 'Consentrator', '3'),
(61, 'Controller Smartsystem', '16'),
(62, 'Armature Sorot 400 Watt', '10'),
(63, 'LED Celling Underpass 200 Watt', '2'),
(64, 'Kontraktor 25 A', '0'),
(65, 'Lampu LED 120 Watt', '10'),
(66, 'Stang 2 x 1.5\"', '87');

-- --------------------------------------------------------

--
-- Table structure for table `stok_barang_lama`
--

CREATE TABLE `stok_barang_lama` (
  `no` int(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `stok_barang` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok_barang_lama`
--

INSERT INTO `stok_barang_lama` (`no`, `tanggal`, `nama_barang`, `stok_barang`) VALUES
(1, '2019-12-31', 'Lampu Son T 250 Watt', '1741'),
(2, '2019-12-31', 'Lampu Son T 150 Watt', '0'),
(3, '2019-12-31', 'Lampu Son T 70 Watt', '2067'),
(4, '2019-12-31', 'Lampu HE 45 Watt', '0'),
(5, '2019-12-31', 'Ballast SON 250 Watt', '1736'),
(6, '2019-12-31', 'Ballast SON 150 Watt', '3'),
(7, '2019-12-31', 'Ballast SON 70 Watt', '2174'),
(8, '2019-12-31', 'Ignitor SI', '363'),
(9, '2019-12-31', 'Ignitor SN 58', '5445'),
(10, '2019-12-31', 'Timer', '132'),
(11, '2019-12-31', 'Kontraktor', '103'),
(12, '2019-12-31', 'NFB 50 A', '0'),
(13, '2019-12-31', 'MCB 6 A', '176'),
(14, '2019-12-31', 'MCB 10 A', '415'),
(15, '2019-12-31', 'MCB 16 A', '324'),
(16, '2019-12-31', 'MCB 25 A', '370'),
(17, '2019-12-31', 'MCB 50 A/1 Phase', '341'),
(18, '2019-12-31', 'Armature 250 W IP 65', '43'),
(19, '2019-12-31', 'Armature 70 W IP 65', '34'),
(20, '2019-12-31', 'Armature Jalan Lingkungan', '1'),
(21, '2019-12-31', 'Armature LP Sorot 250 Watt', '19'),
(22, '2019-12-31', 'Fotocell 6 A', '1817'),
(23, '2019-12-31', 'Fotocell 10 A', '242'),
(24, '2019-12-31', 'Connector', '1782'),
(25, '2019-12-31', 'Fitting E 27', '180'),
(26, '2019-12-31', 'Fitting E 40', '272'),
(27, '2019-12-31', 'Twisted Cable 2x10mm', '1000'),
(28, '2019-12-31', 'Twisted Cable 4x10mm', '80'),
(29, '2019-12-31', 'Kabel NYM 500 V 2x1.5mm', '120.09'),
(30, '2019-12-31', 'Stang 3 Meter', '17'),
(31, '2019-12-31', 'Stang 6 Meter', '19'),
(32, '2019-12-31', 'Tiang Besi', '15'),
(33, '2019-12-31', 'Isolasi', '995'),
(34, '2019-12-31', 'Braket', '150'),
(35, '2019-12-31', 'Stanless', '145'),
(36, '2019-12-31', 'Weid Clamp', '1571'),
(37, '2019-12-31', 'Lampu Hias', '98'),
(38, '2019-12-31', 'Angkur', '85'),
(39, '2019-12-31', 'Rangka Pondasi', '18'),
(40, '2019-12-31', 'Sling', '1483'),
(41, '2019-12-31', 'Stoping', '440'),
(42, '2019-12-31', 'Panel', '23'),
(43, '2019-12-31', 'Gembok Panel', '0'),
(44, '2019-12-31', 'Lampu HPIT 1000 Watt', '24'),
(45, '2019-12-31', 'Ballast 1000 Watt', '25'),
(46, '2019-12-31', 'Armature Lampu HPIT 1000 Watt Sodium Lengkap', '3'),
(47, '2019-12-31', 'Stang 3 Meter 1.5 inch', '0'),
(48, '2019-12-31', 'Philips BRP210 LED 27 Watt', '24'),
(49, '2019-12-31', 'Philips HPIT 400 Watt', '35'),
(50, '2019-12-31', 'Philips HPIT 250 Watt', '42'),
(51, '2019-12-31', 'Ballast MH 400', '36'),
(52, '2019-12-31', 'Ballast MH 250', '52'),
(53, '2019-12-31', 'Twisted Cable 2x16mm', '0'),
(54, '2019-12-31', 'Twisted Cable 4x16mm', '2080'),
(55, '2019-12-31', 'NH-Fuse', '20'),
(56, '2019-12-31', 'Armature Lengkap LED DC 40 Watt', '4'),
(57, '2019-12-31', 'Batterai VLRA 12V 65 A', '6'),
(58, '2019-12-31', 'Batterai Control Regulator 20 A', '0'),
(59, '2019-12-31', 'Armature LED 75 Watt Ellipz', '12'),
(60, '2019-12-31', 'Consentrator', '3'),
(61, '2019-12-31', 'Controller Smartsystem', '16'),
(62, '2019-12-31', 'Armature Sorot 400 Watt', '10'),
(63, '2019-12-31', 'LED Celling Underpass 200 Watt', '2'),
(64, '2019-12-31', 'Kontraktor 25 A', '0'),
(65, '2019-12-31', 'Lampu LED 120 Watt', '10'),
(66, '2019-12-31', 'Stang 2 x 1.5\"', '100'),
(1, '2020/01/31', 'Lampu Son T 250 Watt', '1561'),
(2, '2020/01/31', 'Lampu Son T 150 Watt', '0'),
(3, '2020/01/31', 'Lampu Son T 70 Watt', '1923'),
(4, '2020/01/31', 'Lampu HE 45 Watt', '0'),
(5, '2020/01/31', 'Ballast SON 250 Watt', '1542'),
(6, '2020/01/31', 'Ballast SON 150 Watt', '3'),
(7, '2020/01/31', 'Ballast SON 70 Watt', '2014'),
(8, '2020/01/31', 'Ignitor SI', '363'),
(9, '2020/01/31', 'Ignitor SN 58', '5117'),
(10, '2020/01/31', 'Timer', '101'),
(11, '2020/01/31', 'Kontraktor', '76'),
(12, '2020/01/31', 'NFB 50 A', '0'),
(13, '2020/01/31', 'MCB 6 A', '135'),
(14, '2020/01/31', 'MCB 10 A', '415'),
(15, '2020/01/31', 'MCB 16 A', '295'),
(16, '2020/01/31', 'MCB 25 A', '360'),
(17, '2020/01/31', 'MCB 50 A/1 Phase', '327'),
(18, '2020/01/31', 'Armature 250 W IP 65', '43'),
(19, '2020/01/31', 'Armature 70 W IP 65', '32'),
(20, '2020/01/31', 'Armature Jalan Lingkungan', '1'),
(21, '2020/01/31', 'Armature LP Sorot 250 Watt', '18'),
(22, '2020/01/31', 'Fotocell 6 A', '1737'),
(23, '2020/01/31', 'Fotocell 10 A', '241'),
(24, '2020/01/31', 'Connector', '1730'),
(25, '2020/01/31', 'Fitting E 27', '140'),
(26, '2020/01/31', 'Fitting E 40', '222'),
(27, '2020/01/31', 'Twisted Cable 2x10mm', '0'),
(28, '2020/01/31', 'Twisted Cable 4x10mm', '0'),
(29, '2020/01/31', 'Kabel NYM 500 V 2x1.5mm', '109.7'),
(30, '2020/01/31', 'Stang 3 Meter', '17'),
(31, '2020/01/31', 'Stang 6 Meter', '19'),
(32, '2020/01/31', 'Tiang Besi', '13'),
(33, '2020/01/31', 'Isolasi', '968'),
(34, '2020/01/31', 'Braket', '150'),
(35, '2020/01/31', 'Stanless', '141'),
(36, '2020/01/31', 'Weid Clamp', '1535'),
(37, '2020/01/31', 'Lampu Hias', '98'),
(38, '2020/01/31', 'Angkur', '85'),
(39, '2020/01/31', 'Rangka Pondasi', '18'),
(40, '2020/01/31', 'Sling', '1483'),
(41, '2020/01/31', 'Stoping', '378'),
(42, '2020/01/31', 'Panel', '21'),
(43, '2020/01/31', 'Gembok Panel', '0'),
(44, '2020/01/31', 'Lampu HPIT 1000 Watt', '23'),
(45, '2020/01/31', 'Ballast 1000 Watt', '25'),
(46, '2020/01/31', 'Armature Lampu HPIT 1000 Watt Sodium Lengkap', '3'),
(47, '2020/01/31', 'Stang 3 Meter 1.5 inch', '0'),
(48, '2020/01/31', 'Philips BRP210 LED 27 Watt', '11'),
(49, '2020/01/31', 'Philips HPIT 400 Watt', '35'),
(50, '2020/01/31', 'Philips HPIT 250 Watt', '42'),
(51, '2020/01/31', 'Ballast MH 400', '36'),
(52, '2020/01/31', 'Ballast MH 250', '52'),
(53, '2020/01/31', 'Twisted Cable 2x16mm', '0'),
(54, '2020/01/31', 'Twisted Cable 4x16mm', '2080'),
(55, '2020/01/31', 'NH-Fuse', '20'),
(56, '2020/01/31', 'Armature Lengkap LED DC 40 Watt', '4'),
(57, '2020/01/31', 'Batterai VLRA 12V 65 A', '6'),
(58, '2020/01/31', 'Batterai Control Regulator 20 A', '0'),
(59, '2020/01/31', 'Armature LED 75 Watt Ellipz', '12'),
(60, '2020/01/31', 'Consentrator', '3'),
(61, '2020/01/31', 'Controller Smartsystem', '16'),
(62, '2020/01/31', 'Armature Sorot 400 Watt', '10'),
(63, '2020/01/31', 'LED Celling Underpass 200 Watt', '2'),
(64, '2020/01/31', 'Kontraktor 25 A', '0'),
(65, '2020/01/31', 'Lampu LED 120 Watt', '10'),
(66, '2020/01/31', 'Stang 2 x 1.5\"', '96');

-- --------------------------------------------------------

--
-- Table structure for table `temp_barang_masuk`
--

CREATE TABLE `temp_barang_masuk` (
  `no` int(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_barang_masuk`
--

INSERT INTO `temp_barang_masuk` (`no`, `nama_barang`, `tanggal`, `jumlah`) VALUES
(1, 'Lampu Son T 250 Watt', '2020/01/08', '20'),
(3, 'Lampu Son T 70 Watt', '2020/01/09', '14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hasil_pakai`
--
ALTER TABLE `hasil_pakai`
  ADD KEY `no` (`no`);

--
-- Indexes for table `laporan_sementara`
--
ALTER TABLE `laporan_sementara`
  ADD KEY `no` (`no`);

--
-- Indexes for table `stok_barang`
--
ALTER TABLE `stok_barang`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stok_barang`
--
ALTER TABLE `stok_barang`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hasil_pakai`
--
ALTER TABLE `hasil_pakai`
  ADD CONSTRAINT `hasil_pakai_ibfk_1` FOREIGN KEY (`no`) REFERENCES `stok_barang` (`no`);

--
-- Constraints for table `laporan_sementara`
--
ALTER TABLE `laporan_sementara`
  ADD CONSTRAINT `laporan_sementara_ibfk_1` FOREIGN KEY (`no`) REFERENCES `stok_barang` (`no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
